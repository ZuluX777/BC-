# BC Built — launch checklist

Statuses used throughout: **passed** (verified in this environment, with
evidence), **failed** (a real defect was found — noted as fixed once it was
resolved and re-verified), **not tested** (genuinely not checked here, most
often because it can only be checked against a live deployment), **requires
owner input** (needs a decision or fact from Brandon before it can be
finished or published).

This file only reports what was actually run in this build environment. No
item below is marked passed on the strength of "it should work" — see each
row's evidence.

## How this was verified

- `npm run build`, `npx tsc --noEmit`, `npm run lint` — all clean, zero
  errors/warnings, re-run after every fix below.
- A 48-check Playwright suite (`verify.mjs`, included in this handoff)
  against a production build (`npm run start`) on a real headless Chromium:
  every route's status code and console errors, the full two-step enquiry
  form (validation, step navigation, data retention, honest failure state),
  the mobile menu's dialog/focus-trap/Escape/scroll-lock/focus-return
  behaviour, keyboard navigation (skip link, FAQ disclosure), the honeypot,
  cookie consent, and horizontal-overflow checks at 320/375/768/1024/1440px.
  **Final result: 48/48 passing.**
- Live `curl` testing of `POST /api/enquiry` directly: confirmed the
  honest-failure guarantee holds across repeated retries with the same
  idempotency key, confirmed the honeypot returns a silent fake success with
  no distinguishing signal, confirmed requests from an unrecognised Origin
  are rejected (403).
- Lighthouse (mobile, throttled) against the production build, plus a
  Chrome DevTools Protocol check for CSP violations the Playwright
  console-error listener alone wouldn't have caught.
- Manual visual review of full-page screenshots at five widths plus the
  contact and service pages, which is how three real layout/contrast bugs
  below were actually found (the automated checks didn't catch them — see
  "Bugs found and fixed" below).

### Bugs found and fixed during this build

None of these were present in an earlier "final" pass — each was caught by
deliberately re-checking beyond the automated test suite, then fixed and
re-verified with a full rebuild + re-run of every check above:

1. **Hero grid overflowed at the 1024px breakpoint.** `lg:grid-cols-[46%_54%]`
   combined with `gap-12` — percentage columns don't account for the gap, so
   the grid demanded 48px more than its container, pushing the hero graphic
   past the viewport edge. Fixed to `lg:grid-cols-[0.46fr_0.54fr]` (matching
   the pattern already used correctly elsewhere in the codebase).
2. **Every link's text colour was silently overridden site-wide.**
   `globals.css` had `a { color: inherit; }` outside any `@layer`. Per the
   CSS cascade-layers spec, an unlayered rule beats every layered rule
   regardless of specificity — and Tailwind's utilities all live in
   `@layer utilities` — so this one line was cancelling every `text-*` class
   applied directly to an `<a>` across the whole site, leaving the actual
   rendered colour to whatever was inherited instead. This is why the header
   nav was nearly invisible against the dark header, and why the header CTA
   button showed the wrong colour. Fixed by moving the rule into
   `@layer base`.
3. **The logo rendered 8x too large on every page that uses it** (header,
   footer, homepage About section, About page). `Logo.tsx` wrapped the
   `<img>` in a `<picture>` with no height of its own, so the `<img>`'s
   `h-full` had no real ancestor height to resolve against, and the browser
   fell back to close to the image's natural intrinsic size — blowing the
   header out by roughly 700px and squeezing the nav/CTA into wrapping.
   Fixed by giving `<picture>` an explicit height sourced from each call
   site.
4. **The honeypot field's own validation rule defeated the honeypot.** The
   Zod schema rejected a filled honeypot with `max(0)` before the route's
   silent anti-bot trap ever ran, so a bot got a distinguishing `400`
   validation error instead of a silent fake success — leaking exactly the
   signal a honeypot is meant to withhold. Fixed by letting the field
   through validation so the route's intended silent-trap logic runs.
5. **Idempotency could replay a failed send as a fabricated success.**
   (Found and fixed earlier in this build, before the pass above.) The
   idempotency key was written with the real reference *before* the email
   send was attempted; on failure the claim was never released, so retrying
   with the same key returned the cached reference as if it had succeeded —
   directly violating "never simulate a successful submission." Fixed with
   a two-phase claim (pending sentinel → real reference only on confirmed
   send → claim released on any failure), verified with three consecutive
   live retries all correctly returning an honest 503.
6. **The mobile menu didn't return focus to its trigger on Escape.** Fixed;
   re-verified via Playwright.
7. **A WCAG contrast failure in the decorative "01/02/03" numerals** (found
   via Lighthouse, not the Playwright suite — see below). `aria-hidden`
   alone doesn't satisfy WCAG 1.4.3 (a sighted low-vision visitor still sees
   the text even though a screen reader skips it), so contrast was raised
   to ~3.2:1 (the large-text minimum) while keeping the numerals a quiet
   accent rather than full-weight text.

### Lighthouse (mobile, throttled — lab data, not field data)

| Category | Score |
|---|---|
| Performance | 84 |
| Accessibility | 100 |
| Best Practices | 96 |
| SEO | 100 |

Accessibility and SEO meet/exceed the brief's targets (≥95 accessibility).
Performance (target ≥90) does not yet, on this lab run — see the
Performance row in the table below for what's driving that and what's
realistic to fix pre- vs. post-deployment. This is a **local, throttled lab
run**, not the field/real-user data (Core Web Vitals at the 75th
percentile) the brief's actual target is defined against — that can only be
measured once the site is live with real traffic.

One CSP finding worth recording honestly: Chrome's DevTools Issues panel
shows a single `script-src` violation from Zod's own internal, self-caught
`Function("")` feature-detection call (Zod tries this to decide whether it
can use a faster JIT-compiled validation path, and gracefully falls back
when it can't — e.g. under a CSP, or on Cloudflare Workers, which the same
code explicitly checks for). It's caught inside Zod's own `try/catch`, so
nothing actually breaks — form validation was tested extensively above and
works correctly — but Chrome still logs the blocked `eval` attempt as a CSP
issue regardless of the JS-level catch. The alternative would be adding
`'unsafe-eval'` to `script-src`, which is a real CSP weakening for zero
functional benefit given Zod already degrades gracefully. Left as-is;
flagging it here rather than silently ignoring it.

## The 20 checks (build brief, section K)

| # | Item | Status | Evidence |
|---|---|---|---|
| 1 | Privacy policy page | **Passed** (content) / **requires owner input** (completeness) | `/privacy` is built and reflects what the site actually does (Resend for email, no analytics/Turnstile active by default, no marketing use of enquiry data). It explicitly flags that a registered business address/company number will be added only once trading structure is confirmed — not invented. |
| 2 | Terms & conditions page | **Passed** | `/terms` is website-use terms only; explicitly states a submitted enquiry does not book work or fix a price, and is not a building-works contract. |
| 3 | Secrets off the frontend | **Passed** | `RESEND_API_KEY`, `TURNSTILE_SECRET_KEY`, `UPSTASH_REDIS_REST_TOKEN` are only read in server-only modules (`import "server-only"` in `lib/email.ts`, `lib/kv-store.ts`, `lib/turnstile.ts`). Only `NEXT_PUBLIC_*`-prefixed values reach the client bundle, by Next.js's own convention. |
| 4 | Force HTTPS | **Not tested** | `Strict-Transport-Security` header is set (see security headers below), but the actual HTTP→HTTPS redirect and TLS behaviour only exist once deployed — cannot be verified against a local server. |
| 5 | Cookie consent banner | **Passed** | With no analytics/Turnstile configured (current state), the site shows a plain notice ("this site currently uses only the technology needed to run it — no optional cookies are active") with a dismiss action and no meaningless Accept/Reject choice — matching the brief's explicit instruction not to show a fake consent banner when there's nothing optional to consent to. Verified: notice appears, dismisses, stays dismissed after reload. The consent-gated code path for when analytics *is* configured (equal-weight accept/reject, reopenable preferences) is implemented in `components/consent/` but only exercisable once `NEXT_PUBLIC_PLAUSIBLE_DOMAIN` is actually set — **not tested** in that configured state. |
| 6 | Meta titles + descriptions | **Passed** | Every route has unique metadata sourced from `content/seo.ts`, matching the brief's table verbatim for the routes it specifies. Verified rendered in HTML via Playwright/Lighthouse. |
| 7 | Social preview image | **Passed** | `public/images/og/og-default.jpg`, 1200×630, real logo composited on a branded background. Referenced in `layout.tsx` openGraph metadata. Actual link-preview rendering (Slack/X/etc.) is **not tested** — that requires a publicly reachable URL. |
| 8 | Favicon | **Passed** | `favicon.ico` (multi-size 16/32/48), `icon.png` (512×512), `apple-icon.png` (180×180) — a legible typographic "BC" mark in brand colours, since the real lockup is a wide horizontal logo that isn't legible shrunk into a square. See ASSET-MANIFEST.md. |
| 9 | Sitemap + robots.txt | **Passed** | `sitemap.xml` includes only canonical public pages (excludes `/api/*`, `/thank-you`, and `/projects` entirely while empty). `robots.txt` disallows `/api/` and `/thank-you`, and returns `disallow: /` entirely when `VERCEL_ENV === "preview"`. |
| 10 | Alt text on images | **Passed** | Logo has descriptive alt text; decorative SVGs are `aria-hidden`; project images (currently unreachable — no verified projects) use per-project `coverImageAlt` from the data layer rather than a generic string. |
| 11 | Compress images | **Passed** | Logo served as WebP (130KB) with a PNG fallback, optimised from 1.17MB to 568KB via palette quantization. OG image 113KB. Real photography will need the same treatment once supplied — see ASSET-MANIFEST.md. |
| 12 | Check page load speed | **Passed** (lab) / **not tested** (field) | See the Lighthouse table above. Performance is 84/100 on a throttled mobile lab run, short of the brief's ≥90 target — see the Performance row below for what to do about it. Field Core Web Vitals require a live deployment. |
| 13 | Fix colour contrast | **Passed** | Lighthouse's accessibility category is 100/100 with zero contrast violations, after fixing a real one found during this build (see "Bugs found and fixed," #7). Buttons, nav, form labels/errors, and focus rings were also visually reviewed against the token table in the brief. |
| 14 | Make it mobile friendly | **Passed** | No horizontal overflow at 320/375/768/1024/1440px (automated, and after fixing a real regression — see "Bugs found and fixed," #1). Mobile menu, mobile bottom CTA (with safe-area-inset padding and reserved document space so it never covers content), and the full form flow were tested at 390×844. |
| 15 | Custom 404 page | **Passed** | Verified: `/nonexistent-xyz` returns real HTTP 404, with a styled page offering links to all three services, back-to-homepage and contact CTAs. |
| 16 | Fix broken links | **Passed** (internal) / **not tested** (external) | Every internal route in the site was crawled by the Playwright suite (200 for real routes, 404 for the intentionally-missing one). `tel:`/`mailto:` links use the business's real supplied number/email. No external links exist on the site other than those two. |
| 17 | Form validation | **Passed** | Client-side (Zod, same schema as the server) and server-side validation confirmed independently; error summary + inline errors + focus-first-invalid-field; state preserved across step navigation and after a failed submission; duplicate-submission prevention verified live (three retries with the same idempotency key all correctly failed honestly rather than one succeeding falsely). |
| 18 | Spam protection | **Passed** (what's active) / **requires owner input** (Turnstile) | Honeypot verified live (silent fake success, no signal). Rate limiting is implemented and active (in-memory fallback without Upstash configured — see the Rate limiting row below). Turnstile is implemented but inert until `TURNSTILE_SECRET_KEY` / `NEXT_PUBLIC_TURNSTILE_SITE_KEY` are set — a decision for Brandon/whoever configures the Vercel project. |
| 19 | Set up analytics | **Passed** (adapter) / **requires owner input** (whether to use it at all) | A consent-gated event adapter exists (`components/consent/`), tracking only allowlisted event/prop names (service CTA clicks, form start/step/submit, email/phone clicks) with no personal data, and only loads/fires after explicit consent. It does nothing at all until `NEXT_PUBLIC_PLAUSIBLE_DOMAIN` is set — which is a business decision, not a technical gap. |
| 20 | One clear call to action | **Passed** | "Tell us about your project" is the primary CTA in the header, hero, mobile bottom bar, and final conversion section, and every service card's link leads to the same `/contact` form with its service preselected. |

## Additional launch-readiness items (build brief, section L)

| Area | Status | Detail |
|---|---|---|
| Repository completeness | **Passed** | Full source, `package-lock.json`, `.env.example`, this checklist, ASSET-MANIFEST.md, README.md, `assets-source/` (originals kept separate from optimised `public/` assets). |
| Typecheck / lint / build | **Passed** | `npx tsc --noEmit`, `npm run lint`, `npm run build` all clean — zero errors, zero warnings — re-confirmed after every fix in this file. |
| Keyboard navigation | **Passed** | Skip link is the first Tab stop; mobile menu focus trap, Escape-to-close-and-return-focus, and scroll lock all verified; FAQ disclosures open via keyboard Enter. |
| Server-side rejection paths | **Passed** | Verified live: invalid payload → 400 with field errors; wrong Origin → 403; honeypot filled → silent fake 200; no email config → honest 503, never a fake success, confirmed not to change across retries. |
| Missing configuration handling | **Passed** | The entire site — including a full enquiry submission attempt — was tested with **zero** environment variables set, which is its current state. Every "missing config" path returns an honest, specific response rather than silently succeeding or crashing. |
| Consent behaviour | **Passed** | No optional banner shown when nothing optional is configured (current state); notice dismisses and stays dismissed. |
| Mocked vs. real email | **Passed** | All testing here used the unconfigured (honest-unavailable) path — no real email provider was ever contacted, per the brief's instruction not to send real customer messages during this build. |
| Screenshots | **Passed** | Desktop (1440px: home, contact, services, about) and mobile (390px: home, contact) screenshots were captured against the final build and are included in this handoff under `screenshots/`. |
| Rate limiting | **Passed** (logic) / **requires owner input** (production-grade store) | Implemented and active right now via an in-memory fallback, which only limits per serverless instance — **not a real guarantee across multiple concurrent Vercel instances**. Configuring `UPSTASH_REDIS_REST_URL` / `_TOKEN` (free tier is enough to start) removes this gap; this is flagged, not hidden, in both `.env.example` and `lib/kv-store.ts`'s own comments. |
| Performance | **Failed → partially addressed** | 84/100 mobile Lighthouse performance (target ≥90), driven mainly by Largest Contentful Paint (~4.0s in this throttled lab run) and render-blocking CSS. Contributing factors that are fixable now: the two largest opportunities Lighthouse reports are "reduce unused JavaScript" (~99KB, most likely framework code not yet needed on first paint) and "render-blocking requests" (~810ms, one CSS chunk). These are normal Next.js/Tailwind output characteristics, not bugs, and typically improve further once served from Vercel's edge network with real HTTP/2+CDN caching rather than a local single-process dev/start server — but should not be assumed fixed until measured live. Treat the ≥90 target as **not yet met**, to be re-measured after deployment. |
| Structured data | **Passed** | Organization, WebSite, BreadcrumbList (per-page) and Service (per service page) JSON-LD. Deliberately excludes: street address, aggregateRating, opening hours, sameAs — none of these are confirmed facts, and the brief is explicit that a service-area label isn't a substitute for Google's required physical address for LocalBusiness rich-result eligibility. |
| Security headers | **Passed** | CSP, `X-Content-Type-Options`, `X-Frame-Options`, `Referrer-Policy`, `Permissions-Policy`, `Strict-Transport-Security` all confirmed present on live responses (`curl -I`). CSP was tested against real page loads, not just written and assumed — see the CSP finding above (one benign, self-caught violation from a dependency, left undocumented nowhere — logged here). |
| Logs / health endpoint | **Passed** | `/api/health` returns only boolean configuration flags (`emailConfigured`, `turnstileConfigured`, `distributedRateLimitConfigured`) — no actual secret values, provider responses, or enquiry content. Enquiry logging records reference/status/provider-message-ID only, never full submitted content. |

## Requires owner input before public launch (build brief, section 4)

These do not block having a working, deployable source project — they
determine what can be honestly turned on or published:

- **Domain**: `www.bcbuilt.co.uk` did not resolve during the original
  research pass. `SITE_URL` in `.env.example` defaults to that address as a
  placeholder — confirm the real domain, and www vs. non-www, before
  deploying, and preserve existing email DNS records when pointing the
  domain at Vercel.
- **Email sending domain**: Resend requires a verified sending domain.
  Recommended: a subdomain such as `notifications.bcbuilt.co.uk` for
  `ENQUIRY_FROM_EMAIL`, so the existing `info@bcbuilt.co.uk` mailbox's DNS
  is never touched.
- **Trading entity**: do not assume a limited company. The card lists
  Brandon Cunningham as "Director," which is not proof of a registered Ltd
  company. Confirm before adding any companies-house disclosures to the
  footer/terms/privacy pages.
- **Anti-spam configuration**: Turnstile site/secret keys, and ideally an
  Upstash Redis instance for real distributed rate limiting — both optional
  to launch, both recommended.
- **Analytics**: whether to use Plausible (or anything) at all, and its
  configured domain.
- **Real project photography**: at least one verified, owner-approved
  project (with permission to publish) to populate `content/projects.ts`
  and activate the "Our work" section/nav link/sitemap entries.
- **Business facts not yet confirmed**: opening hours, service radius
  beyond "Brighton & Hove and Sussex," whether free site visits/quotations
  are offered, VAT status, any trade memberships or insurance to state.
  None of these are currently claimed anywhere on the site — they were
  deliberately left out rather than invented.
- **A portrait of Brandon**, if he wants one — the About page currently
  uses the logo and typography instead of an empty photo placeholder.

## What genuinely cannot be tested until deployment

- Real inbox delivery at `info@bcbuilt.co.uk` (provider acceptance is not
  proof of delivery — this needs an actual send with real credentials,
  checking the inbox and spam folder, and confirming Reply-To works).
- HTTP→HTTPS redirect and live TLS.
- Domain redirect behaviour (www ↔ non-www, once decided).
- Real-user Core Web Vitals (field data) and a Lighthouse run against the
  actual production URL rather than a local server.
- Social-share preview rendering on real platforms.
- Distributed rate limiting under real concurrent Vercel traffic (only
  meaningfully testable with Upstash configured and real load).
