// Live verification suite used to produce LAUNCH-CHECKLIST.md's results.
// Not part of the app's own dependency tree — install playwright separately
// to re-run it: `npm install --no-save playwright`, then
// `npm run build && npm run start -- -p 3100` in one terminal and
// `node verify.mjs` in another. Override PORT/CHROME_PATH as needed for
// your environment.
import { chromium } from "playwright";
import fs from "fs";

const BASE = `http://localhost:${process.env.PORT || 3100}`;
const results = [];
function log(name, ok, detail = "") {
  results.push({ name, ok, detail });
  console.log(`${ok ? "PASS" : "FAIL"} — ${name}${detail ? " — " + detail : ""}`);
}

const browser = await chromium.launch({
  executablePath: process.env.CHROME_PATH || undefined,
  args: ["--no-sandbox"],
});

async function withPage(fn) {
  const context = await browser.newContext();
  const page = await context.newPage();
  const consoleErrors = [];
  page.on("console", (msg) => {
    if (msg.type() === "error") consoleErrors.push(msg.text());
  });
  page.on("pageerror", (err) => consoleErrors.push(String(err)));
  try {
    await fn(page, consoleErrors);
  } finally {
    await context.close();
  }
  return consoleErrors;
}

// 1. Every route loads with no console errors
const routes = ["/", "/services", "/services/building", "/services/renovations", "/services/property-maintenance", "/about", "/areas-we-cover", "/contact", "/privacy", "/terms", "/cookies", "/nonexistent-xyz"];
for (const route of routes) {
  const errors = await withPage(async (page) => {
    const resp = await page.goto(BASE + route, { waitUntil: "networkidle" });
    const status = resp.status();
    const expectedOk = route === "/nonexistent-xyz" ? status === 404 : status === 200;
    log(`route ${route} status`, expectedOk, `got ${status}`);
  });
  // For the intentional 404 route, Chrome logs the top-level navigation's
  // non-2xx response itself as a "Failed to load resource: 404" console
  // message — that is expected browser behaviour for any 404 page, not an
  // application error, so it is excluded from this check for that one route.
  const realErrors =
    route === "/nonexistent-xyz"
      ? errors.filter((e) => !/Failed to load resource.*404/i.test(e))
      : errors;
  log(`route ${route} no console errors`, realErrors.length === 0, realErrors.join(" | "));
}

// 2. Mobile viewport + mobile menu focus trap + escape + scroll lock
await withPage(async (page) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto(BASE + "/", { waitUntil: "networkidle" });
  const menuButton = page.getByRole("button", { name: /menu/i });
  await menuButton.click();
  const dialog = page.getByRole("dialog", { name: /site menu/i });
  await dialog.waitFor({ state: "visible" });
  log("mobile menu opens as dialog", true);

  const bodyOverflow = await page.evaluate(() => document.body.style.overflow);
  log("scroll lock applied while menu open", bodyOverflow === "hidden", `overflow=${bodyOverflow}`);

  const closeFocused = await page.evaluate(() => document.activeElement?.getAttribute("aria-label"));
  log("focus moves to close button on open", closeFocused === "Close menu", `got ${closeFocused}`);

  await page.keyboard.press("Escape");
  await dialog.waitFor({ state: "hidden" });
  log("Escape closes mobile menu", true);

  const focusedAfterClose = await page.evaluate(() => document.activeElement?.textContent?.trim());
  log("focus returns to trigger after Escape", focusedAfterClose === "Menu", `got ${focusedAfterClose}`);
});

// 3. Skip link + keyboard focus visible
await withPage(async (page) => {
  await page.goto(BASE + "/", { waitUntil: "networkidle" });
  await page.keyboard.press("Tab");
  const skipLinkFocused = await page.evaluate(() => document.activeElement?.textContent?.trim());
  log("first Tab focuses skip link", skipLinkFocused === "Skip to main content", `got ${skipLinkFocused}`);
});

// 4. Reduced motion respected (entrance animation duration collapses)
await withPage(async (page) => {
  await page.emulateMedia({ reducedMotion: "reduce" });
  await page.goto(BASE + "/", { waitUntil: "networkidle" });
  const dur = await page.evaluate(() => {
    const el = document.querySelector(".reveal");
    if (!el) return null;
    return getComputedStyle(el).animationDuration;
  });
  // Chromium normalises computed animation-duration to seconds (e.g. "1e-05s"
  // for the "0.01ms !important" rule), rather than echoing the authored unit
  // back verbatim — compare numerically rather than by exact string.
  const durSeconds = dur ? parseFloat(dur) : NaN;
  log(
    "reduced motion collapses entrance animation",
    Number.isFinite(durSeconds) && durSeconds <= 0.0001,
    `got ${dur}`,
  );
});

// 5. Full enquiry form flow (contact page), including validation + step nav
await withPage(async (page) => {
  await page.goto(BASE + "/contact", { waitUntil: "networkidle" });

  // Try to continue with empty step 1 -> expect validation error summary
  await page.getByRole("button", { name: "Continue" }).click();
  const errorSummary = page.getByRole("alert").filter({ hasText: "There is a problem" });
  await errorSummary.waitFor({ state: "visible", timeout: 3000 });
  log("empty step-1 submit shows error summary", true);

  // Fill step 1 correctly
  await page.getByRole("radio", { name: "Building" }).check({ force: true });
  await page.locator("#enquiry-postcode").fill("BN1 1AB");
  await page.locator("#enquiry-description").fill("Rear single-storey extension, roughly twenty square metres, brick to match existing.");
  await page.getByRole("button", { name: "Continue" }).click();

  await page.locator("#enquiry-name").waitFor({ state: "visible", timeout: 3000 });
  log("advances to step 2 with valid step-1 data", true);

  // Go back, verify step-1 data preserved
  await page.getByRole("button", { name: "Back" }).click();
  const postcodeVal = await page.locator("#enquiry-postcode").inputValue();
  log("step-1 data preserved when navigating back", postcodeVal === "BN1 1AB", `got ${postcodeVal}`);

  // Forward again, fill step 2, submit (email not configured -> expect honest failure message, not fake success)
  await page.getByRole("button", { name: "Continue" }).click();
  await page.locator("#enquiry-name").fill("Jane Doe");
  await page.locator("#enquiry-email").fill("jane@example.com");
  await page.getByRole("button", { name: "Send project enquiry" }).click();

  const failureBox = page.getByRole("alert").filter({ hasText: "We could not send your enquiry" });
  await failureBox.waitFor({ state: "visible", timeout: 5000 });
  log("honest failure shown when email unavailable (never simulated success)", true);

  const nameStillThere = await page.locator("#enquiry-name").inputValue();
  log("form data preserved after failed submission", nameStillThere === "Jane Doe", `got ${nameStillThere}`);
});

// 6. Preselected service via query param
await withPage(async (page) => {
  await page.goto(BASE + "/contact?service=Renovations", { waitUntil: "networkidle" });
  const checked = await page.getByRole("radio", { name: "Renovations" }).isChecked();
  log("service preselected from query param", checked === true, `checked=${checked}`);
});

// 7. Honeypot field is hidden from visual + a11y tree but present in DOM
//    Note: Playwright's .isVisible() only checks display/visibility/opacity —
//    it does not treat off-screen positioning as hidden, so it is not the
//    right check for the standard "position off-canvas" hiding technique
//    used here. We instead assert the element's box is actually outside the
//    viewport (the real visual-hiding behaviour) plus the aria-hidden a11y
//    check.
await withPage(async (page) => {
  await page.goto(BASE + "/contact", { waitUntil: "networkidle" });
  const honeypot = page.locator("#enquiry-company");
  const box = await honeypot.boundingBox();
  const viewport = page.viewportSize();
  const offCanvas = !!box && !!viewport && (box.x + box.width <= 0 || box.x >= viewport.width);
  const ariaHiddenParent = await page.evaluate(() => {
    const el = document.getElementById("enquiry-company");
    return el?.closest('[aria-hidden="true"]') !== null;
  });
  log("honeypot field positioned off-canvas (not visible to sighted users)", offCanvas, `box=${JSON.stringify(box)}`);
  log("honeypot wrapped in aria-hidden container", ariaHiddenParent, `ariaHidden=${ariaHiddenParent}`);
});

// 8. Cookie consent notice (no analytics configured -> plain notice, no accept/reject)
await withPage(async (page) => {
  await page.goto(BASE + "/", { waitUntil: "networkidle" });
  const region = page.getByRole("region", { name: "Cookie notice" });
  await region.waitFor({ state: "visible", timeout: 3000 });
  const hasAccept = await page.getByRole("button", { name: "Accept" }).count();
  log("no accept/reject banner shown when analytics not configured", hasAccept === 0, `acceptButtons=${hasAccept}`);
  await page.getByRole("button", { name: "Got it" }).click();
  await region.waitFor({ state: "hidden", timeout: 3000 });
  log("notice dismissible and stays dismissed", true);
  await page.reload({ waitUntil: "networkidle" });
  const stillHidden = await region.isHidden().catch(() => true);
  log("notice stays dismissed after reload", stillHidden);
});

// 9. FAQ accessible disclosure works via keyboard
await withPage(async (page) => {
  await page.goto(BASE + "/", { waitUntil: "networkidle" });
  const summary = page.locator("details summary").first();
  await summary.scrollIntoViewIfNeeded();
  await summary.focus();
  await page.keyboard.press("Enter");
  const isOpen = await page.locator("details").first().evaluate((el) => el.open);
  log("FAQ disclosure opens via keyboard Enter", isOpen === true, `open=${isOpen}`);
});

// 10. Responsive screenshots
const shotDir = new URL("./screenshots", import.meta.url).pathname;
fs.mkdirSync(shotDir, { recursive: true });
const breakpoints = [
  { name: "320", width: 320, height: 700 },
  { name: "375", width: 375, height: 800 },
  { name: "768", width: 768, height: 1024 },
  { name: "1024", width: 1024, height: 800 },
  { name: "1440", width: 1440, height: 900 },
];
for (const bp of breakpoints) {
  await withPage(async (page) => {
    await page.setViewportSize({ width: bp.width, height: bp.height });
    await page.goto(BASE + "/", { waitUntil: "networkidle" });
    const hasHorizontalOverflow = await page.evaluate(() => document.documentElement.scrollWidth > document.documentElement.clientWidth + 1);
    log(`no horizontal overflow at ${bp.width}px`, !hasHorizontalOverflow, `scrollWidth vs clientWidth`);
    await page.screenshot({ path: `${shotDir}/home-${bp.name}.png`, fullPage: true });
  });
}
// contact + service page screenshots at desktop + mobile for the deliverable
await withPage(async (page) => {
  await page.setViewportSize({ width: 1440, height: 900 });
  await page.goto(BASE + "/contact", { waitUntil: "networkidle" });
  await page.screenshot({ path: `${shotDir}/contact-1440.png`, fullPage: true });
  await page.goto(BASE + "/services/renovations", { waitUntil: "networkidle" });
  await page.screenshot({ path: `${shotDir}/service-1440.png`, fullPage: true });
});
await withPage(async (page) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto(BASE + "/", { waitUntil: "networkidle" });
  await page.screenshot({ path: `${shotDir}/home-mobile-390.png`, fullPage: true });
  await page.goto(BASE + "/contact", { waitUntil: "networkidle" });
  await page.screenshot({ path: `${shotDir}/contact-mobile-390.png`, fullPage: true });
});

await browser.close();

const failed = results.filter((r) => !r.ok);
console.log(`\n${results.length - failed.length}/${results.length} checks passed.`);
fs.writeFileSync(
  new URL("./verify-results.json", import.meta.url).pathname,
  JSON.stringify(results, null, 2),
);
if (failed.length > 0) {
  console.log("\nFAILED CHECKS:");
  for (const f of failed) console.log(` - ${f.name}: ${f.detail}`);
  process.exit(1);
}
