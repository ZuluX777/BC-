# Asset manifest

Every image asset in this project, where it came from, and whether it
depicts real BC Built work. Per the build brief: no image here is presented
as a real BC Built project photo, review, or accreditation — this is a new
business with no such assets supplied yet.

## Source assets (`assets-source/`)

Kept separately from `public/` — these are the original, unprocessed files
as uploaded, not served by the website. If a higher-resolution or vector
(SVG) version of the logo becomes available, replace these and re-derive
everything in `public/images/logo/` and the favicon/icon files below from
it.

| File | Origin | Original size | Notes |
|---|---|---|---|
| `bc-built-logo-original.png` | Supplied by the user (screenshot of the BC Built logo) | 1774×887px | Source for every logo asset below. Not a vector original — if BC Built has a native AI/EPS/SVG file, use that instead for higher fidelity at large sizes. |
| `bc-built-businesscard-original.png` | Supplied by the user (photo/scan of Brandon Cunningham's business card) | 1659×948px | Source of the business facts used throughout the site (name, phone, email, tagline). Not used as an image anywhere on the site — it's a reference document, not a design asset. |

## Served assets (`public/images/`)

| File | Derived from | Size | Processing | Real BC Built asset? |
|---|---|---|---|---|
| `logo/bc-built-logo.png` | `bc-built-logo-original.png` | 1551×783px, 568KB | Cropped to the logo's bounding box (screenshot UI/whitespace removed), then palette-quantized (pngquant) to cut file size ~50% with no visible quality loss. PNG fallback for browsers without WebP support. | Yes — the real supplied logo, not redrawn or redesigned. |
| `logo/bc-built-logo.webp` | Same crop as above | 1551×783px, 130KB | WebP re-encode of the same crop, served first via `<picture><source>`. | Yes |
| `og/og-default.jpg` | `bc-built-logo-original.png` | 1200×630px, 113KB | Composited onto a branded ink-black background with the tagline text added beneath, sized correctly for Open Graph / Twitter card previews. | Yes — same real logo, on a purpose-built social-share background. |

## Favicon / touch icon (`src/app/`)

Next.js's file-based icon convention — these are served automatically at
`/favicon.ico`, `/icon.png` etc.

| File | Size | Approach | Why |
|---|---|---|---|
| `icon.png` | 512×512px | A clean typographic "BC" mark with an underline, in brand ink/yellow — not a crop of the full wordmark lockup. | The real logo is a wide horizontal lockup (roughly 2:1). Shrunk into a square favicon it becomes illegible at 16–32px. A short, legible typographic mark in the same brand colours reads correctly at tab-icon size, per the brief's "legible at small sizes" requirement. Swap for a real square brand mark if BC Built has one. |
| `apple-icon.png` | 180×180px | Same "BC" mark, resized for iOS home-screen icons. | Same reasoning as above. |
| `favicon.ico` | 16/32/48px (multi-size ICO) | Same mark, rasterised into a proper multi-resolution `.ico`. | Multi-size so browsers pick the sharpest version for the context (browser tab vs. bookmarks bar etc.), rather than scaling a single 16px bitmap up or down. |

## Project photography (`content/projects.ts`)

Empty — intentionally. Per the brief: **do not invent projects, reviews, or
claimed experience for a new business with no supplied evidence.** The data
file, its route (`/projects`, `/projects/[slug]`), and the "Our work" nav
link are all fully built and wired together, but the route correctly 404s
and the nav link stays hidden until at least one verified entry — with
owner-approved photography and real project facts — is added here.

## What is deliberately absent

- No stock photography anywhere on the site (hero uses an original geometric
  graphic built from the brand's own roofline/diagonal language — see
  `src/components/home/HeroGraphic.tsx` — not a stock "handshake on a
  building site" image).
- No customer review screenshots, star ratings, or testimonial photos.
- No trade-body/accreditation badges (FMB, Checkatrade, etc.) — none were
  supplied or confirmed.
- No Brandon Cunningham portrait — none was supplied. The About page is
  composed with typography and the brand mark instead of an empty
  photo placeholder.
