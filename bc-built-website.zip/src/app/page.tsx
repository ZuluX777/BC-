import type { Metadata } from "next";
import { routeSeo } from "@/content/seo";
import { Hero } from "@/components/home/Hero";
import { ServicesSection } from "@/components/home/ServicesSection";
import { WorkSection } from "@/components/home/WorkSection";
import { AboutSection } from "@/components/home/AboutSection";
import { ProcessSection } from "@/components/home/ProcessSection";
import { AreaSection } from "@/components/home/AreaSection";
import { FaqSection } from "@/components/home/FaqSection";
import { FinalCtaSection } from "@/components/home/FinalCtaSection";

export const metadata: Metadata = {
  title: routeSeo["/"].title,
  description: routeSeo["/"].description,
  alternates: { canonical: "/" },
  openGraph: { title: routeSeo["/"].title, description: routeSeo["/"].description, url: "/" },
};

export default function HomePage() {
  return (
    <>
      <Hero />
      <ServicesSection />
      <WorkSection />
      <AboutSection />
      <ProcessSection />
      <AreaSection />
      <FaqSection />
      <FinalCtaSection />
    </>
  );
}
