import type { Metadata } from "next";
import { routeSeo } from "@/content/seo";
import { business } from "@/content/business";
import { Container } from "@/components/ui/Container";
import { Eyebrow } from "@/components/ui/Eyebrow";
import { Rule } from "@/components/ui/Rule";
import { Button } from "@/components/ui/Button";
import { Logo } from "@/components/layout/Logo";
import { BreadcrumbJsonLd } from "@/components/seo/JsonLd";

const seo = routeSeo["/about"];

export const metadata: Metadata = {
  title: seo.title,
  description: seo.description,
  alternates: { canonical: "/about" },
  openGraph: { title: seo.title, description: seo.description, url: "/about" },
};

export default function AboutPage() {
  return (
    <>
      <BreadcrumbJsonLd items={[{ name: "Home", path: "/" }, { name: "About", path: "/about" }]} />
      <section className="bg-ink py-14 text-white md:py-20">
        <Container>
          <Eyebrow>About BC Built</Eyebrow>
          <h1 className="mt-2 text-4xl md:text-5xl">Meet Brandon.</h1>
          <Rule className="mt-5" />
        </Container>
      </section>

      <section className="bg-white py-14 md:py-20">
        <Container className="grid gap-10 md:grid-cols-[1fr_1.2fr] md:items-center md:gap-16">
          <div className="flex items-center justify-center rounded bg-ink p-10 md:p-14">
            <Logo className="h-20 md:h-28" />
          </div>
          <div>
            <p className="text-base leading-relaxed text-body-dark md:text-lg">
              {business.director} is the {business.directorTitle.toLowerCase()} of {business.name}, a building,
              renovations and property maintenance business serving {business.town} and {business.region}.
            </p>
            <p className="mt-4 text-base leading-relaxed text-body-dark md:text-lg">
              Have something in mind for your property? Get in touch and tell him about it — share your postcode,
              a short description of the job and your preferred timing, and Brandon will get back to you to discuss
              the next step.
            </p>
            <div className="mt-8">
              <Button href="/contact" showArrow>
                Talk to Brandon about your project
              </Button>
            </div>
          </div>
        </Container>
      </section>
    </>
  );
}
