import { NextRequest, NextResponse } from "next/server";
import { enquirySchema } from "@/lib/validation";
import { normalisePostcode } from "@/lib/postcode";
import { sendEnquiryEmail } from "@/lib/email";
import { generateEnquiryReference } from "@/lib/reference";
import { checkRateLimit } from "@/lib/rate-limit";
import { setIfAbsent, set as kvSet, del as kvDel, get as kvGet } from "@/lib/kv-store";
import { verifyTurnstile } from "@/lib/turnstile";
import { logEnquiryOutcome } from "@/lib/logger";
import { getSiteUrl, isProduction } from "@/lib/env";

export const runtime = "nodejs";

const MAX_BODY_BYTES = 20_000;
const IDEMPOTENCY_SUCCESS_TTL_SECONDS = 15 * 60;
const IDEMPOTENCY_PENDING_TTL_SECONDS = 90;
const PENDING_SENTINEL = "__pending__";

type ApiResponse =
  | { ok: true; reference: string }
  | {
      ok: false;
      error:
        | "validation"
        | "unavailable"
        | "rate_limited"
        | "bot_suspected"
        | "origin_rejected"
        | "duplicate_in_progress"
        | "server_error";
      message: string;
      fieldErrors?: Record<string, string>;
    };

function json(body: ApiResponse, status: number) {
  return NextResponse.json(body, { status });
}

function getClientIdentifier(req: NextRequest): string {
  const forwardedFor = req.headers.get("x-forwarded-for");
  if (forwardedFor) return forwardedFor.split(",")[0]!.trim();
  return "unknown";
}

function isAllowedOrigin(req: NextRequest): boolean {
  const siteUrl = getSiteUrl();
  let siteHost: string;
  try {
    siteHost = new URL(siteUrl).host;
  } catch {
    siteHost = "";
  }
  const requestHost = req.headers.get("host") ?? "";
  const origin = req.headers.get("origin");
  const referer = req.headers.get("referer");

  if (origin) {
    try {
      const originHost = new URL(origin).host;
      return originHost === requestHost || originHost === siteHost;
    } catch {
      return false;
    }
  }
  if (referer) {
    try {
      const refererHost = new URL(referer).host;
      return refererHost === requestHost || refererHost === siteHost;
    } catch {
      return false;
    }
  }
  // No Origin or Referer at all is unusual for a browser fetch() POST.
  // Allow in development so local tooling (curl, tests) keeps working;
  // reject in production as a defence-in-depth measure.
  return !isProduction();
}

export async function POST(req: NextRequest) {
  const rawBody = await req.text();
  if (rawBody.length > MAX_BODY_BYTES) {
    return json({ ok: false, error: "validation", message: "Request too large." }, 413);
  }

  if (!isAllowedOrigin(req)) {
    return json({ ok: false, error: "origin_rejected", message: "Request origin could not be verified." }, 403);
  }

  let parsedJson: unknown;
  try {
    parsedJson = JSON.parse(rawBody);
  } catch {
    return json({ ok: false, error: "validation", message: "Could not read the submitted form." }, 400);
  }

  const parsed = enquirySchema.safeParse(parsedJson);
  if (!parsed.success) {
    const fieldErrors: Record<string, string> = {};
    for (const issue of parsed.error.issues) {
      const key = issue.path.join(".") || "form";
      if (!fieldErrors[key]) fieldErrors[key] = issue.message;
    }
    return json(
      { ok: false, error: "validation", message: "Please check the highlighted fields.", fieldErrors },
      400,
    );
  }

  const values = parsed.data;

  // Honeypot: a real visitor never populates this hidden field.
  if (values.company && values.company.trim().length > 0) {
    logEnquiryOutcome({ reference: "n/a", status: "rejected", detail: "honeypot" });
    // Respond as if successful so an automated submitter gets no signal.
    return json({ ok: true, reference: generateEnquiryReference() }, 200);
  }

  const clientId = getClientIdentifier(req);

  const rateLimit = await checkRateLimit(clientId);
  if (!rateLimit.success) {
    logEnquiryOutcome({ reference: "n/a", status: "rejected", detail: "rate_limited" });
    return json(
      { ok: false, error: "rate_limited", message: "Too many enquiries submitted recently. Please try again shortly, or email info@bcbuilt.co.uk." },
      429,
    );
  }

  const turnstileOutcome = await verifyTurnstile(values.turnstileToken, clientId);
  if (turnstileOutcome === "failed") {
    logEnquiryOutcome({ reference: "n/a", status: "rejected", detail: "turnstile_failed" });
    return json(
      { ok: false, error: "bot_suspected", message: "We could not verify this submission. Please try again." },
      400,
    );
  }

  // Idempotency, in two phases so a FAILED send can never be replayed back
  // as a false success on retry:
  //   1. Claim the key with a short-lived "pending" sentinel before sending.
  //   2. Only overwrite it with the real reference once the email has
  //      actually been sent. On any failure the claim is released (deleted)
  //      so the next identical submission gets a genuine fresh attempt.
  const idempotencyStoreKey = `enquiry:idempotency:${values.idempotencyKey}`;
  const existing = await kvGet(idempotencyStoreKey);

  if (existing && existing !== PENDING_SENTINEL) {
    // A prior attempt with this exact key already succeeded — replay the
    // same reference instead of sending a second email.
    logEnquiryOutcome({ reference: existing, status: "duplicate" });
    return json({ ok: true, reference: existing }, 200);
  }

  if (existing === PENDING_SENTINEL) {
    // Another request with this exact key is still being processed
    // (double-click, or a slow first attempt still in flight).
    return json(
      {
        ok: false,
        error: "duplicate_in_progress",
        message: "Your enquiry is already being sent. Please wait a moment before trying again.",
      },
      409,
    );
  }

  const claimed = await setIfAbsent(idempotencyStoreKey, PENDING_SENTINEL, IDEMPOTENCY_PENDING_TTL_SECONDS);
  if (!claimed) {
    // Lost a race with a concurrent identical submission that claimed the
    // key a moment ago.
    return json(
      {
        ok: false,
        error: "duplicate_in_progress",
        message: "Your enquiry is already being sent. Please wait a moment before trying again.",
      },
      409,
    );
  }

  const reference = generateEnquiryReference();
  const normalisedPostcode = normalisePostcode(values.postcode);

  const result = await sendEnquiryEmail({
    ...values,
    reference,
    normalisedPostcode,
    submittedAtIso: new Date().toISOString(),
  });

  if (result.status === "sent") {
    await kvSet(idempotencyStoreKey, reference, IDEMPOTENCY_SUCCESS_TTL_SECONDS);
    logEnquiryOutcome({ reference, status: "sent", providerMessageId: result.providerMessageId });
    return json({ ok: true, reference }, 200);
  }

  // Release the claim on any failure — never cache a failure as if it were
  // a success. The client can retry with the same idempotency key (a real
  // second attempt, not a replay) once the underlying issue is fixed.
  await kvDel(idempotencyStoreKey);

  if (result.status === "unavailable") {
    logEnquiryOutcome({ reference, status: "unavailable", detail: result.reason });
    return json(
      {
        ok: false,
        error: "unavailable",
        message: "We could not send your enquiry just now. Your details are still here. Please try again, or email info@bcbuilt.co.uk.",
      },
      503,
    );
  }

  logEnquiryOutcome({ reference, status: "error", detail: result.reason });
  return json(
    {
      ok: false,
      error: "server_error",
      message: "We could not send your enquiry just now. Your details are still here. Please try again, or email info@bcbuilt.co.uk.",
    },
    502,
  );
}

export async function GET() {
  return json({ ok: false, error: "validation", message: "Method not allowed." }, 405);
}
