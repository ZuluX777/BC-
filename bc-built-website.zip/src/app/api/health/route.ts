import { NextResponse } from "next/server";
import { getEmailConfig, getTurnstileServerConfig } from "@/lib/env";
import { isDistributedStoreConfigured } from "@/lib/kv-store";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * Configuration status only — booleans, never values. Useful for the site
 * owner to confirm production environment variables are wired up after
 * deployment, without exposing any secret or its shape.
 */
export async function GET() {
  return NextResponse.json({
    ok: true,
    emailConfigured: getEmailConfig() !== null,
    turnstileConfigured: getTurnstileServerConfig() !== null,
    distributedRateLimitConfigured: isDistributedStoreConfigured(),
  });
}
