import type { Metadata } from "next";
import { business } from "@/content/business";
import { Container } from "@/components/ui/Container";
import { Button } from "@/components/ui/Button";

export const metadata: Metadata = {
  title: "Enquiry received | BC Built",
  description: "Your project enquiry has been submitted to BC Built.",
  robots: { index: false, follow: false },
};

export default async function ThankYouPage({
  searchParams,
}: {
  searchParams: Promise<{ [key: string]: string | string[] | undefined }>;
}) {
  const params = await searchParams;
  const ref = typeof params.ref === "string" ? params.ref : null;

  return (
    <section className="bg-paper py-20 md:py-28">
      <Container className="max-w-xl text-center">
        <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-yellow">
          <svg aria-hidden="true" width="28" height="28" viewBox="0 0 28 28" fill="none">
            <path d="M6 14.5 11.5 20 22 8" stroke="#101110" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
        <h1 className="mt-6 text-3xl md:text-4xl">Thanks. Your enquiry has been submitted.</h1>
        <p className="mt-5 text-base leading-relaxed text-muted-dark md:text-lg">
          Brandon will review the details and get in touch. If you need to add anything, email{" "}
          <a href={`mailto:${business.email}`} className="font-semibold text-body-dark underline decoration-yellow decoration-2 underline-offset-4">
            {business.email}
          </a>{" "}
          and include your enquiry reference.
        </p>
        {ref ? (
          <p className="mt-6 inline-block rounded border-2 border-ink px-5 py-3 font-display text-lg font-semibold tracking-wide">
            Reference: {ref}
          </p>
        ) : null}
        <div className="mt-10">
          <Button href="/" variant="secondary">
            Back to homepage
          </Button>
        </div>
      </Container>
    </section>
  );
}
