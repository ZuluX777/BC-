import type { Metadata } from "next";
import { routeSeo } from "@/content/seo";
import { business } from "@/content/business";
import { Container } from "@/components/ui/Container";
import { Eyebrow } from "@/components/ui/Eyebrow";
import { Rule } from "@/components/ui/Rule";

const seo = routeSeo["/terms"];

export const metadata: Metadata = {
  title: seo.title,
  description: seo.description,
  alternates: { canonical: "/terms" },
};

export default function TermsPage() {
  return (
    <>
      <section className="bg-ink py-14 text-white md:py-16">
        <Container>
          <Eyebrow>Legal</Eyebrow>
          <h1 className="mt-2 text-4xl md:text-5xl">Website terms of use.</h1>
          <Rule className="mt-5" />
        </Container>
      </section>

      <section className="bg-white py-14 md:py-20">
        <Container className="max-w-3xl">
          <div className="space-y-8 text-base leading-relaxed text-body-dark">
            <p className="text-sm text-muted-dark">Last reviewed: 25 September 2026.</p>

            <p>
              These terms cover use of this website only. They are not, and are not intended to be, a contract for
              any building, renovation or property maintenance work. Submitting the enquiry form does not book work,
              agree a price or create a contract of any kind — it simply starts a conversation. Any building works
              contract is a separate agreement, arranged directly with {business.director} once a scope and
              quotation have been discussed and agreed.
            </p>

            <div>
              <h2 className="text-2xl">Using this site</h2>
              <p className="mt-3">
                You may browse this website and use the enquiry form to contact {business.name} about a genuine
                project. Please do not use the form to submit false, misleading or malicious content, or attempt to
                disrupt or gain unauthorised access to the site or its systems.
              </p>
            </div>

            <div>
              <h2 className="text-2xl">Accuracy</h2>
              <p className="mt-3">
                We try to keep this website accurate and up to date. Descriptions of services are general — the
                specific scope, materials, timing and cost of any project are confirmed directly with you before any
                work begins.
              </p>
            </div>

            <div>
              <h2 className="text-2xl">Intellectual property</h2>
              <p className="mt-3">
                The BC Built name, logo and the content of this website belong to {business.name} unless stated
                otherwise. Please do not reproduce them without permission.
              </p>
            </div>

            <div>
              <h2 className="text-2xl">Liability</h2>
              <p className="mt-3">
                This website is provided as a way to learn about {business.name} and get in touch. To the extent
                permitted by law, {business.name} is not liable for any loss arising from use of this website itself
                (as distinct from any building works contract, which is governed by its own separate terms).
              </p>
            </div>

            <div>
              <h2 className="text-2xl">Trading status</h2>
              <p className="mt-3">
                Details of {business.name}’s trading structure (for example, sole trader or limited company) and any
                related statutory disclosures will be added here once confirmed. Nothing on this website should be
                taken to imply a specific trading structure.
              </p>
            </div>

            <div>
              <h2 className="text-2xl">Contact</h2>
              <p className="mt-3">
                Questions about these terms can be sent to{" "}
                <a href={`mailto:${business.email}`} className="underline decoration-2 underline-offset-2">
                  {business.email}
                </a>
                .
              </p>
            </div>
          </div>
        </Container>
      </section>
    </>
  );
}
