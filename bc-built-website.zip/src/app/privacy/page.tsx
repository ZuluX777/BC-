import type { Metadata } from "next";
import { routeSeo } from "@/content/seo";
import { business } from "@/content/business";
import { Container } from "@/components/ui/Container";
import { Eyebrow } from "@/components/ui/Eyebrow";
import { Rule } from "@/components/ui/Rule";

const seo = routeSeo["/privacy"];

export const metadata: Metadata = {
  title: seo.title,
  description: seo.description,
  alternates: { canonical: "/privacy" },
};

export default function PrivacyPage() {
  return (
    <>
      <section className="bg-ink py-14 text-white md:py-16">
        <Container>
          <Eyebrow>Legal</Eyebrow>
          <h1 className="mt-2 text-4xl md:text-5xl">Privacy notice.</h1>
          <Rule className="mt-5" />
        </Container>
      </section>

      <section className="bg-white py-14 md:py-20">
        <Container className="max-w-3xl">
          <div className="prose-like space-y-8 text-base leading-relaxed text-body-dark">
            <p className="text-sm text-muted-dark">Last reviewed: 25 September 2026.</p>

            <p>
              This notice explains what happens when you submit an enquiry or otherwise browse this website. It is
              written to reflect what this website actually does — it is not a substitute for legal advice, and
              {` ${business.name} `}should have it reviewed before relying on it.
            </p>

            <div>
              <h2 className="text-2xl">Who is responsible for your information</h2>
              <p className="mt-3">
                {business.name} ({business.director}) is responsible for the information collected through this
                website. You can contact us at{" "}
                <a href={`mailto:${business.email}`} className="underline decoration-2 underline-offset-2">
                  {business.email}
                </a>{" "}
                or {business.phoneDisplay}.
              </p>
              <p className="mt-3 text-sm text-muted-dark">
                A registered business address and company number will be added here if {business.name} operates as
                a registered company — this has not yet been confirmed.
              </p>
            </div>

            <div>
              <h2 className="text-2xl">What we collect and why</h2>
              <p className="mt-3">When you submit the project enquiry form, we collect:</p>
              <ul className="mt-3 list-disc space-y-1 pl-5">
                <li>The service, postcode and description of the work you provide</li>
                <li>Your preferred timing and approximate budget, if you choose to share them</li>
                <li>Your name, email address and, if you provide it, phone number</li>
                <li>Your preferred way for us to reply, and whether you have photos or plans to send separately</li>
              </ul>
              <p className="mt-3">
                We use this information to respond to your enquiry, discuss your project and, if you go ahead, carry
                out the work. We do not use it for marketing, and submitting an enquiry does not sign you up to a
                mailing list.
              </p>
            </div>

            <div>
              <h2 className="text-2xl">How your enquiry is sent</h2>
              <p className="mt-3">
                The enquiry form sends your details by email to {business.name} using Resend, a transactional email
                service that delivers the message on our behalf. Resend processes the content of your enquiry only
                to deliver that email; see{" "}
                <a href="https://resend.com/legal/privacy-policy" target="_blank" rel="noreferrer" className="underline decoration-2 underline-offset-2">
                  Resend’s privacy policy
                </a>{" "}
                for details of their own processing.
              </p>
              <p className="mt-3">
                To reduce spam, the form may also use Cloudflare Turnstile (a challenge that checks a submission is
                likely to be from a person, not a script) and a rate-limiting service (Upstash) that temporarily
                records submission activity to stop the form being flooded. These are only active where {business.name}{" "}
                has configured them, and they process technical signals (such as an approximate submission rate),
                not the content of your message.
              </p>
            </div>

            <div>
              <h2 className="text-2xl">Cookies and analytics</h2>
              <p className="mt-3">
                See our{" "}
                <a href="/cookies" className="underline decoration-2 underline-offset-2">
                  cookies notice
                </a>{" "}
                for the current position on cookies and any optional analytics. Optional analytics, where used, is
                off by default and only runs if you actively accept it.
              </p>
            </div>

            <div>
              <h2 className="text-2xl">How long we keep it</h2>
              <p className="mt-3">
                We keep enquiry details for as long as reasonably needed to respond to your enquiry and to discuss
                and, where relevant, carry out any resulting work, and for a limited period afterwards in case you
                get back in touch. A specific retention schedule has not yet been set by {business.name}.
              </p>
            </div>

            <div>
              <h2 className="text-2xl">Your rights</h2>
              <p className="mt-3">
                Under UK data protection law you generally have the right to ask what information we hold about
                you, to ask us to correct or delete it, and to object to or restrict certain processing. To exercise
                any of these, contact {business.email}. You can also complain to the{" "}
                <a href="https://ico.org.uk/make-a-complaint/" target="_blank" rel="noreferrer" className="underline decoration-2 underline-offset-2">
                  Information Commissioner’s Office (ICO)
                </a>{" "}
                if you believe your information has been mishandled.
              </p>
            </div>

            <div>
              <h2 className="text-2xl">Changes to this notice</h2>
              <p className="mt-3">
                We may update this notice as the website or our processes change. The date at the top shows when it
                was last reviewed.
              </p>
            </div>
          </div>
        </Container>
      </section>
    </>
  );
}
