import type { Metadata } from "next";
import { routeSeo } from "@/content/seo";
import { business } from "@/content/business";
import { enquiryServiceOptions } from "@/content/services";
import { Container } from "@/components/ui/Container";
import { Eyebrow } from "@/components/ui/Eyebrow";
import { Rule } from "@/components/ui/Rule";
import { EnquiryForm, type EnquirySource } from "@/components/forms/EnquiryForm";
import { BreadcrumbJsonLd } from "@/components/seo/JsonLd";

const seo = routeSeo["/contact"];

export const metadata: Metadata = {
  title: seo.title,
  description: seo.description,
  alternates: { canonical: "/contact" },
  openGraph: { title: seo.title, description: seo.description, url: "/contact" },
};

const allowlistedServices = new Set(enquiryServiceOptions.map((o) => o.value));
const sourceByService: Record<string, EnquirySource> = {
  Building: "building",
  Renovations: "renovations",
  "Property maintenance": "property-maintenance",
};

export default async function ContactPage({
  searchParams,
}: {
  searchParams: Promise<{ [key: string]: string | string[] | undefined }>;
}) {
  const params = await searchParams;
  const requested = typeof params.service === "string" ? params.service : undefined;
  const defaultService = requested && allowlistedServices.has(requested) ? requested : undefined;
  const source: EnquirySource = (defaultService && sourceByService[defaultService]) || "contact";

  return (
    <>
      <BreadcrumbJsonLd items={[{ name: "Home", path: "/" }, { name: "Contact", path: "/contact" }]} />
      <section className="bg-ink py-14 text-white md:py-20">
        <Container>
          <Eyebrow>Contact</Eyebrow>
          <h1 className="mt-2 text-4xl md:text-5xl">Discuss your project.</h1>
          <Rule className="mt-5" />
          <p className="mt-6 max-w-xl text-base leading-relaxed text-body-light md:text-lg">
            A few details are enough to start the conversation. Prefer to speak directly? Call or email using the
            details below.
          </p>
          <div className="mt-6 flex flex-wrap gap-x-8 gap-y-2 text-base">
            <a href={`tel:${business.phoneHref}`} className="font-semibold underline decoration-yellow decoration-2 underline-offset-4 hover:text-yellow">
              {business.phoneDisplay}
            </a>
            <a href={`mailto:${business.email}`} className="font-semibold underline decoration-yellow decoration-2 underline-offset-4 hover:text-yellow">
              {business.email}
            </a>
          </div>
        </Container>
      </section>

      <section className="bg-paper py-14 md:py-20">
        <Container className="max-w-2xl">
          <div className="rounded border border-black/10 bg-white p-6 shadow-sm md:p-10">
            <EnquiryForm defaultService={defaultService} source={source} />
          </div>
        </Container>
      </section>
    </>
  );
}
