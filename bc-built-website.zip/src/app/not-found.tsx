import { business } from "@/content/business";
import { services } from "@/content/services";
import { Container } from "@/components/ui/Container";
import { Button } from "@/components/ui/Button";
import { Rule } from "@/components/ui/Rule";

export default function NotFound() {
  return (
    <section className="bg-paper py-20 md:py-28">
      <Container className="max-w-2xl text-center">
        <p className="font-display text-lg font-semibold uppercase tracking-[0.14em] text-muted-dark">404</p>
        <h1 className="mt-2 text-4xl md:text-5xl">We couldn’t find that page.</h1>
        <Rule className="mx-auto mt-5" />
        <p className="mt-6 text-base leading-relaxed text-muted-dark md:text-lg">
          The page you were looking for may have moved, or the link might be out of date. Here are some places to
          go instead.
        </p>

        <div className="mt-10 grid gap-3 sm:grid-cols-3">
          {services.map((service) => (
            <a
              key={service.slug}
              href={`/services/${service.slug}`}
              className="rounded border border-black/10 bg-white px-4 py-3 text-sm font-semibold text-body-dark hover:border-ink"
            >
              {service.cardTitle}
            </a>
          ))}
        </div>

        <div className="mt-10 flex flex-wrap justify-center gap-4">
          <Button href="/" showArrow>
            Back to homepage
          </Button>
          <Button href="/contact" variant="secondary">
            Contact BC Built
          </Button>
        </div>

        <p className="mt-8 text-sm text-muted-dark">
          Or reach us directly: {business.phoneDisplay} · {business.email}
        </p>
      </Container>
    </section>
  );
}
