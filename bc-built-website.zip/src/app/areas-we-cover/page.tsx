import type { Metadata } from "next";
import { routeSeo } from "@/content/seo";
import { confirmedCoverage } from "@/content/areas";
import { Container } from "@/components/ui/Container";
import { Eyebrow } from "@/components/ui/Eyebrow";
import { Rule } from "@/components/ui/Rule";
import { Button } from "@/components/ui/Button";
import { BreadcrumbJsonLd } from "@/components/seo/JsonLd";

const seo = routeSeo["/areas-we-cover"];

export const metadata: Metadata = {
  title: seo.title,
  description: seo.description,
  alternates: { canonical: "/areas-we-cover" },
  openGraph: { title: seo.title, description: seo.description, url: "/areas-we-cover" },
};

export default function AreasWeCoverPage() {
  return (
    <>
      <BreadcrumbJsonLd items={[{ name: "Home", path: "/" }, { name: "Areas we cover", path: "/areas-we-cover" }]} />
      <section className="bg-ink py-14 text-white md:py-20">
        <Container>
          <Eyebrow>Coverage</Eyebrow>
          <h1 className="mt-2 text-4xl md:text-5xl">
            {confirmedCoverage[0]}. Across {confirmedCoverage[1]}.
          </h1>
          <Rule className="mt-5" />
          <p className="mt-6 max-w-xl text-base leading-relaxed text-body-light md:text-lg">
            Tell us where your property is and what you need doing. We will confirm whether we can help in your
            area.
          </p>
        </Container>
      </section>

      <section className="bg-white py-14 md:py-20">
        <Container className="max-w-2xl">
          <h2 className="text-2xl md:text-3xl">Confirmed coverage</h2>
          <ul className="mt-6 space-y-3">
            {confirmedCoverage.map((area) => (
              <li key={area} className="flex items-center gap-3 text-lg font-semibold text-body-dark">
                <span className="h-2 w-2 shrink-0 rounded-full bg-yellow" aria-hidden="true" />
                {area}
              </li>
            ))}
          </ul>
          <p className="mt-8 text-base leading-relaxed text-muted-dark">
            Not sure if you’re in range? Include your postcode in an enquiry and we will confirm whether BC Built
            can help.
          </p>
          <div className="mt-8">
            <Button href="/contact" showArrow>
              Tell us about your project
            </Button>
          </div>
        </Container>
      </section>
    </>
  );
}
