import type { MetadataRoute } from "next";
import { getSiteUrl, isPreviewDeployment } from "@/lib/env";

/**
 * robots.txt is not access control — the API routes below are also
 * protected by their own server-side checks (validation, rate limiting,
 * origin checks). This just keeps well-behaved crawlers out of routes that
 * are never meant to be indexed.
 */
export default function robots(): MetadataRoute.Robots {
  const siteUrl = getSiteUrl();

  if (isPreviewDeployment()) {
    return { rules: { userAgent: "*", disallow: "/" } };
  }

  return {
    rules: {
      userAgent: "*",
      allow: "/",
      disallow: ["/api/", "/thank-you"],
    },
    sitemap: `${siteUrl}/sitemap.xml`,
  };
}
