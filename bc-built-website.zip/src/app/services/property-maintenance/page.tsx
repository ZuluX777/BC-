import type { Metadata } from "next";
import { getServiceBySlug } from "@/content/services";
import { routeSeo } from "@/content/seo";
import { ServicePageContent } from "@/components/services/ServicePageContent";

const service = getServiceBySlug("property-maintenance")!;
const seo = routeSeo["/services/property-maintenance"];

export const metadata: Metadata = {
  title: seo.title,
  description: seo.description,
  alternates: { canonical: "/services/property-maintenance" },
  openGraph: { title: seo.title, description: seo.description, url: "/services/property-maintenance" },
};

export default function PropertyMaintenanceServicePage() {
  return <ServicePageContent service={service} />;
}
