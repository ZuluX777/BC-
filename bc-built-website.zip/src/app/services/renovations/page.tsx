import type { Metadata } from "next";
import { getServiceBySlug } from "@/content/services";
import { routeSeo } from "@/content/seo";
import { ServicePageContent } from "@/components/services/ServicePageContent";

const service = getServiceBySlug("renovations")!;
const seo = routeSeo["/services/renovations"];

export const metadata: Metadata = {
  title: seo.title,
  description: seo.description,
  alternates: { canonical: "/services/renovations" },
  openGraph: { title: seo.title, description: seo.description, url: "/services/renovations" },
};

export default function RenovationsServicePage() {
  return <ServicePageContent service={service} />;
}
