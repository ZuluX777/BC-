import type { Metadata } from "next";
import { getServiceBySlug } from "@/content/services";
import { routeSeo } from "@/content/seo";
import { ServicePageContent } from "@/components/services/ServicePageContent";

const service = getServiceBySlug("building")!;
const seo = routeSeo["/services/building"];

export const metadata: Metadata = {
  title: seo.title,
  description: seo.description,
  alternates: { canonical: "/services/building" },
  openGraph: { title: seo.title, description: seo.description, url: "/services/building" },
};

export default function BuildingServicePage() {
  return <ServicePageContent service={service} />;
}
