import type { Metadata } from "next";
import Link from "next/link";
import { services } from "@/content/services";
import { routeSeo } from "@/content/seo";
import { Container } from "@/components/ui/Container";
import { Eyebrow } from "@/components/ui/Eyebrow";
import { Rule } from "@/components/ui/Rule";
import { BreadcrumbJsonLd } from "@/components/seo/JsonLd";

const seo = routeSeo["/services"];

export const metadata: Metadata = {
  title: seo.title,
  description: seo.description,
  alternates: { canonical: "/services" },
  openGraph: { title: seo.title, description: seo.description, url: "/services" },
};

export default function ServicesIndexPage() {
  return (
    <>
      <BreadcrumbJsonLd items={[{ name: "Home", path: "/" }, { name: "Services", path: "/services" }]} />
      <section className="bg-ink py-14 text-white md:py-20">
        <Container>
          <Eyebrow>What we do</Eyebrow>
          <h1 className="mt-2 text-4xl md:text-5xl">Building, renovations &amp; property maintenance.</h1>
          <Rule className="mt-5" />
          <p className="mt-6 max-w-xl text-base leading-relaxed text-body-light md:text-lg">
            Choose a service below to see what to share and discuss your project with Brandon.
          </p>
        </Container>
      </section>

      <section className="bg-paper py-14 md:py-20">
        <Container className="grid gap-6 md:grid-cols-3">
          {services.map((service) => (
            <Link
              key={service.slug}
              href={`/services/${service.slug}`}
              className="group flex flex-col rounded border border-black/10 bg-white p-6 transition-colors hover:border-ink"
            >
              <h2 className="text-2xl">{service.cardTitle}</h2>
              <p className="mt-3 flex-1 text-base leading-relaxed text-muted-dark">{service.cardBody}</p>
              <span className="mt-5 inline-flex items-center gap-2 text-sm font-semibold text-body-dark underline decoration-yellow decoration-2 underline-offset-4">
                {service.cardLinkLabel}
                <svg aria-hidden="true" width="16" height="16" viewBox="0 0 16 16" fill="none" className="transition-transform duration-200 group-hover:translate-x-1">
                  <path d="M2 8h11M9 4l4 4-4 4" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </span>
            </Link>
          ))}
        </Container>
      </section>
    </>
  );
}
