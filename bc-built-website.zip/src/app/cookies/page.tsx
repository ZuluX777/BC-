import type { Metadata } from "next";
import { routeSeo } from "@/content/seo";
import { Container } from "@/components/ui/Container";
import { Eyebrow } from "@/components/ui/Eyebrow";
import { Rule } from "@/components/ui/Rule";

const seo = routeSeo["/cookies"];

export const metadata: Metadata = {
  title: seo.title,
  description: seo.description,
  alternates: { canonical: "/cookies" },
};

const analyticsConfigured = Boolean(process.env.NEXT_PUBLIC_PLAUSIBLE_DOMAIN);

export default function CookiesPage() {
  return (
    <>
      <section className="bg-ink py-14 text-white md:py-16">
        <Container>
          <Eyebrow>Legal</Eyebrow>
          <h1 className="mt-2 text-4xl md:text-5xl">Cookies.</h1>
          <Rule className="mt-5" />
        </Container>
      </section>

      <section className="bg-white py-14 md:py-20">
        <Container className="max-w-3xl">
          <div className="space-y-8 text-base leading-relaxed text-body-dark">
            <p className="text-sm text-muted-dark">Last reviewed: 25 September 2026.</p>

            <div>
              <h2 className="text-2xl">Strictly necessary</h2>
              <p className="mt-3">
                This website stores one small preference in your browser’s local storage to remember your cookie
                choice (or, where no optional technology is active, that you have seen this notice) so we do not ask
                again on every visit. This is not a tracking cookie, is never sent to a server, and does not require
                consent as it is necessary for the site to function as intended.
              </p>
            </div>

            <div>
              <h2 className="text-2xl">Optional analytics</h2>
              {analyticsConfigured ? (
                <>
                  <p className="mt-3">
                    With your consent, this website uses privacy-focused analytics to understand how the site is
                    used — for example, which pages are visited and which buttons are used. This analytics does not
                    use tracking cookies and does not collect your name, email, phone number or anything you type
                    into the enquiry form.
                  </p>
                  <p className="mt-3">
                    Analytics stays off until you accept it in the cookie banner, and you can change your mind at any
                    time using “Cookie settings” in the footer. Rejecting or withdrawing consent stops the analytics
                    script loading and no further events are recorded.
                  </p>
                </>
              ) : (
                <p className="mt-3">
                  This deployment does not currently have any optional analytics or advertising technology
                  configured, so there is nothing optional to consent to — no analytics script runs and no banner
                  asking you to accept one is shown. If that changes, this page and the cookie banner will be
                  updated to match, and analytics will stay off until you actively accept it.
                </p>
              )}
            </div>

            <div>
              <h2 className="text-2xl">What we do not use</h2>
              <p className="mt-3">
                This website does not use advertising or retargeting pixels, session-replay tracking, or third-party
                marketing cookies.
              </p>
            </div>

            <div>
              <h2 className="text-2xl">Managing your choice</h2>
              <p className="mt-3">
                You can accept or reject optional analytics from the cookie banner when it appears, and revisit that
                choice at any time via “Cookie settings” in the site footer. You can also clear your browser’s local
                storage for this site to reset your choice.
              </p>
            </div>
          </div>
        </Container>
      </section>
    </>
  );
}
