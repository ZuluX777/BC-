import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Image from "next/image";
import { getProjectBySlug, verifiedProjects } from "@/content/projects";
import { Container } from "@/components/ui/Container";
import { Eyebrow } from "@/components/ui/Eyebrow";
import { Rule } from "@/components/ui/Rule";
import { Button } from "@/components/ui/Button";
import { BreadcrumbJsonLd } from "@/components/seo/JsonLd";
import { contactHrefForService } from "@/lib/enquiry-link";

export function generateStaticParams() {
  return verifiedProjects.map((p) => ({ slug: p.slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const project = getProjectBySlug(slug);
  if (!project) return {};
  return {
    title: `${project.title} | BC Built`,
    description: `${project.brief} — a ${project.service.toLowerCase()} project by BC Built in ${project.locationLabel}.`,
    alternates: { canonical: `/projects/${project.slug}` },
  };
}

export default async function ProjectPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const project = getProjectBySlug(slug);
  if (!project) notFound();

  return (
    <>
      <BreadcrumbJsonLd
        items={[
          { name: "Home", path: "/" },
          { name: "Our work", path: "/projects" },
          { name: project.title, path: `/projects/${project.slug}` },
        ]}
      />
      <section className="bg-ink py-14 text-white md:py-20">
        <Container>
          <Eyebrow>{project.locationLabel} · {project.service}</Eyebrow>
          <h1 className="mt-2 text-4xl md:text-5xl">{project.title}</h1>
          <Rule className="mt-5" />
        </Container>
      </section>

      <section className="bg-white py-14 md:py-20">
        <Container className="max-w-3xl">
          <div className="relative aspect-[16/9] overflow-hidden rounded">
            <Image src={project.coverImage} alt={project.coverImageAlt} fill className="object-cover" priority />
          </div>
          <div className="mt-10 space-y-8 text-base leading-relaxed text-body-dark">
            <div>
              <h2 className="text-2xl">The brief</h2>
              <p className="mt-3">{project.brief}</p>
            </div>
            <div>
              <h2 className="text-2xl">The work</h2>
              <p className="mt-3">{project.work}</p>
            </div>
            <div>
              <h2 className="text-2xl">The result</h2>
              <p className="mt-3">{project.result}</p>
            </div>
          </div>
          <div className="mt-10">
            <Button href={contactHrefForService(project.service)} showArrow>
              Discuss a similar project
            </Button>
          </div>
        </Container>
      </section>
    </>
  );
}
