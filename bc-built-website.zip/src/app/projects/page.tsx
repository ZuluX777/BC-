import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Image from "next/image";
import Link from "next/link";
import { verifiedProjects } from "@/content/projects";
import { routeSeo } from "@/content/seo";
import { Container } from "@/components/ui/Container";
import { Eyebrow } from "@/components/ui/Eyebrow";
import { Rule } from "@/components/ui/Rule";
import { BreadcrumbJsonLd } from "@/components/seo/JsonLd";

const seo = routeSeo["/projects"];

export const metadata: Metadata = {
  title: seo.title,
  description: seo.description,
  alternates: { canonical: "/projects" },
};

/**
 * This is a new business with no owner-approved project photography yet.
 * Per the build brief, an empty portfolio must never be published — so this
 * route 404s until at least one verified project exists in
 * content/projects.ts, at which point it (and the navigation link, and the
 * sitemap entry) all activate automatically.
 */
export default function ProjectsIndexPage() {
  if (verifiedProjects.length === 0) {
    notFound();
  }

  return (
    <>
      <BreadcrumbJsonLd items={[{ name: "Home", path: "/" }, { name: "Our work", path: "/projects" }]} />
      <section className="bg-ink py-14 text-white md:py-20">
        <Container>
          <Eyebrow>Our work</Eyebrow>
          <h1 className="mt-2 text-4xl md:text-5xl">Recent projects.</h1>
          <Rule className="mt-5" />
        </Container>
      </section>
      <section className="bg-white py-14 md:py-20">
        <Container className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {verifiedProjects.map((project) => (
            <Link key={project.slug} href={`/projects/${project.slug}`} className="group block overflow-hidden rounded">
              <div className="relative aspect-[4/3]">
                <Image src={project.coverImage} alt={project.coverImageAlt} fill className="object-cover transition-transform duration-300 group-hover:scale-[1.02]" />
              </div>
              <div className="border border-t-0 border-black/10 p-5">
                <p className="font-display text-xs font-semibold uppercase tracking-wide text-muted-dark">
                  {project.locationLabel} · {project.service}
                </p>
                <h2 className="mt-1 text-xl">{project.title}</h2>
              </div>
            </Link>
          ))}
        </Container>
      </section>
    </>
  );
}
