import type { MetadataRoute } from "next";
import { getSiteUrl } from "@/lib/env";
import { verifiedProjects } from "@/content/projects";
import { services } from "@/content/services";

/**
 * Canonical public pages only. Excludes API routes, /thank-you (noindex,
 * receipt page), and /projects entirely while there are no verified
 * entries — an empty portfolio is never published, so it is never listed
 * here either.
 */
export default function sitemap(): MetadataRoute.Sitemap {
  const siteUrl = getSiteUrl();
  const now = new Date();

  const staticRoutes = [
    "/",
    "/services",
    ...services.map((s) => `/services/${s.slug}`),
    "/about",
    "/areas-we-cover",
    "/contact",
    "/privacy",
    "/terms",
    "/cookies",
  ];

  const projectRoutes =
    verifiedProjects.length > 0 ? ["/projects", ...verifiedProjects.map((p) => `/projects/${p.slug}`)] : [];

  return [...staticRoutes, ...projectRoutes].map((path) => ({
    url: `${siteUrl}${path}`,
    lastModified: now,
    changeFrequency: path === "/" ? "weekly" : "monthly",
    priority: path === "/" ? 1 : 0.6,
  }));
}
