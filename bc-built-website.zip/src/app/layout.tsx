import type { Metadata, Viewport } from "next";
import "./globals.css";
import { getSiteUrl } from "@/lib/env";
import { SkipLink } from "@/components/layout/SkipLink";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { PageBody } from "@/components/layout/PageBody";
import { BottomStack } from "@/components/layout/BottomStack";
import { ConsentProvider } from "@/components/consent/ConsentProvider";
import { OrganizationJsonLd, WebSiteJsonLd } from "@/components/seo/JsonLd";

const siteUrl = getSiteUrl();

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: "BC Built | Builders in Brighton & Hove",
    template: "%s",
  },
  description:
    "Building, renovations and property maintenance in Brighton & Hove and Sussex. Tell Brandon at BC Built about your project.",
  openGraph: {
    type: "website",
    locale: "en_GB",
    siteName: "BC Built",
    images: [{ url: "/images/og/og-default.jpg", width: 1200, height: 630, alt: "BC Built — Building, Renovations, Property Maintenance" }],
  },
  twitter: {
    card: "summary_large_image",
  },
  robots: {
    index: true,
    follow: true,
  },
  alternates: {
    canonical: "/",
  },
};

export const viewport: Viewport = {
  themeColor: "#101110",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en-GB">
      <body className="flex min-h-screen flex-col bg-paper font-body text-body-dark">
        <OrganizationJsonLd />
        <WebSiteJsonLd />
        <ConsentProvider>
          <SkipLink />
          <Header />
          <PageBody>{children}</PageBody>
          <Footer />
          <BottomStack />
        </ConsentProvider>
      </body>
    </html>
  );
}
