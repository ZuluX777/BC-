"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import Script from "next/script";
import { type AnalyticsEventName, type AnalyticsEventProps, sanitiseAnalyticsProps } from "@/lib/analytics-events";

export type ConsentStatus = "unset" | "accepted" | "rejected";

const STORAGE_KEY = "bcbuilt-cookie-consent";
const PLAUSIBLE_DOMAIN = process.env.NEXT_PUBLIC_PLAUSIBLE_DOMAIN;
const PLAUSIBLE_SRC = process.env.NEXT_PUBLIC_PLAUSIBLE_SRC || "https://plausible.io/js/script.tagged-events.js";

export const analyticsConfigured = Boolean(PLAUSIBLE_DOMAIN);

interface ConsentContextValue {
  status: ConsentStatus;
  ready: boolean;
  analyticsConfigured: boolean;
  accept: () => void;
  reject: () => void;
  reset: () => void;
  track: (name: AnalyticsEventName, props?: AnalyticsEventProps) => void;
}

const ConsentContext = createContext<ConsentContextValue | null>(null);

declare global {
  interface Window {
    plausible?: (event: string, options?: { props?: Record<string, string | number> }) => void;
  }
}

export function ConsentProvider({ children }: { children: React.ReactNode }) {
  const [status, setStatus] = useState<ConsentStatus>("unset");
  const [ready, setReady] = useState(false);

  useEffect(() => {
    // One-time hydration from localStorage after mount — localStorage is
    // unavailable during SSR/first render, so this can't be done as a lazy
    // useState initialiser without a hydration mismatch. Intentional single
    // extra render on mount only, not a cascading update loop.
    try {
      const stored = window.localStorage.getItem(STORAGE_KEY);
      if (stored === "accepted" || stored === "rejected") {
        // eslint-disable-next-line react-hooks/set-state-in-effect
        setStatus(stored);
      }
    } catch {
      // Private browsing / blocked storage — treat as unset for this visit.
    }
    setReady(true);
  }, []);

  const persist = useCallback((value: ConsentStatus) => {
    setStatus(value);
    try {
      window.localStorage.setItem(STORAGE_KEY, value);
    } catch {
      // Ignore storage failures; consent still applies for this page view.
    }
  }, []);

  const accept = useCallback(() => persist("accepted"), [persist]);
  const reject = useCallback(() => persist("rejected"), [persist]);
  const reset = useCallback(() => persist("unset"), [persist]);

  const track = useCallback(
    (name: AnalyticsEventName, props?: AnalyticsEventProps) => {
      if (!analyticsConfigured) return;
      if (status !== "accepted") return;
      if (typeof window === "undefined" || !window.plausible) return;
      window.plausible(name, { props: sanitiseAnalyticsProps(props) });
    },
    [status],
  );

  const value = useMemo<ConsentContextValue>(
    () => ({ status, ready, analyticsConfigured, accept, reject, reset, track }),
    [status, ready, accept, reject, reset, track],
  );

  return (
    <ConsentContext.Provider value={value}>
      {children}
      {analyticsConfigured && status === "accepted" ? (
        <Script
          defer
          data-domain={PLAUSIBLE_DOMAIN}
          src={PLAUSIBLE_SRC}
          strategy="afterInteractive"
        />
      ) : null}
    </ConsentContext.Provider>
  );
}

export function useConsent() {
  const ctx = useContext(ConsentContext);
  if (!ctx) throw new Error("useConsent must be used within ConsentProvider");
  return ctx;
}
