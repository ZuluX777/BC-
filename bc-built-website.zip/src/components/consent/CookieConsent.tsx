"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useConsent, analyticsConfigured } from "@/components/consent/ConsentProvider";
import { Button } from "@/components/ui/Button";

const NOTICE_DISMISSED_KEY = "bcbuilt-necessary-only-notice-dismissed";

export function CookieConsent() {
  const { status, ready, accept, reject } = useConsent();
  const [noticeDismissed, setNoticeDismissed] = useState(true);

  useEffect(() => {
    // One-time hydration from localStorage after mount — see the equivalent
    // comment in ConsentProvider for why this can't be a lazy useState
    // initialiser (localStorage is unavailable during SSR/first render).
    if (analyticsConfigured) return;
    try {
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setNoticeDismissed(window.localStorage.getItem(NOTICE_DISMISSED_KEY) === "1");
    } catch {
      setNoticeDismissed(false);
    }
  }, []);

  if (!ready) return null;

  if (!analyticsConfigured) {
    // No optional technology is configured on this deployment — an
    // accept/reject banner would be meaningless. Show a short, honest
    // notice instead, per the build brief.
    if (noticeDismissed) return null;
    return (
      <div
        role="region"
        aria-label="Cookie notice"
        className="border-t border-yellow/30 bg-ink px-4 py-4 text-body-light md:px-6"
      >
        <div className="mx-auto flex max-w-(--max-content) flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <p className="text-sm leading-relaxed">
            This site currently uses only the technology needed to run it — no optional cookies are active. Read our{" "}
            <Link href="/cookies" className="underline decoration-yellow underline-offset-2 hover:text-yellow">
              cookies notice
            </Link>
            .
          </p>
          <div className="shrink-0">
            <Button
              variant="secondary"
              size="sm"
              onClick={() => {
                setNoticeDismissed(true);
                try {
                  window.localStorage.setItem(NOTICE_DISMISSED_KEY, "1");
                } catch {
                  /* ignore */
                }
              }}
            >
              Got it
            </Button>
          </div>
        </div>
      </div>
    );
  }

  if (status !== "unset") return null;

  return (
    <div
      role="region"
      aria-label="Cookie preferences"
      className="border-t border-yellow/30 bg-ink px-4 py-4 text-body-light md:px-6"
    >
      <div className="mx-auto flex max-w-(--max-content) flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <p className="text-sm leading-relaxed">
          We use optional analytics cookies to understand how this site is used. They stay off unless you accept them. Read our{" "}
          <Link href="/cookies" className="underline decoration-yellow underline-offset-2 hover:text-yellow">
            cookies notice
          </Link>{" "}
          for details.
        </p>
        <div className="flex shrink-0 gap-3">
          <Button variant="secondary" size="sm" onClick={reject}>
            Reject
          </Button>
          <Button variant="primary" size="sm" onClick={accept}>
            Accept
          </Button>
        </div>
      </div>
    </div>
  );
}

/** Footer link that reopens the preferences banner and lets a visitor change their choice. */
export function CookiePreferencesButton() {
  const { reset, analyticsConfigured: configured } = useConsent();
  if (!configured) return null;
  return (
    <button
      type="button"
      onClick={reset}
      className="underline decoration-transparent decoration-2 underline-offset-2 transition hover:decoration-yellow focus-visible:decoration-yellow"
    >
      Cookie settings
    </button>
  );
}
