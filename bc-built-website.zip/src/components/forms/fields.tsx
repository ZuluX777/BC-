"use client";

import { useId } from "react";
import { cn } from "@/lib/cn";

function ErrorIcon() {
  return (
    <svg aria-hidden="true" width="16" height="16" viewBox="0 0 16 16" fill="none" className="shrink-0">
      <circle cx="8" cy="8" r="7" stroke="currentColor" strokeWidth="1.4" />
      <path d="M8 4.5v4M8 11h.01" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
    </svg>
  );
}

interface FieldShellProps {
  label: string;
  hint?: string;
  error?: string;
  required?: boolean;
  htmlFor: string;
  children: (describedBy: string | undefined) => React.ReactNode;
}

export function FieldShell({ label, hint, error, required, htmlFor, children }: FieldShellProps) {
  const hintId = hint ? `${htmlFor}-hint` : undefined;
  const errorId = error ? `${htmlFor}-error` : undefined;
  const describedBy = [hintId, errorId].filter(Boolean).join(" ") || undefined;

  return (
    <div className="flex flex-col gap-1.5">
      <label htmlFor={htmlFor} className="font-body text-sm font-semibold text-body-dark">
        {label}
        {required ? <span aria-hidden="true" className="ml-1 text-error">*</span> : null}
        {!required ? <span className="ml-1 font-normal text-muted-dark">(optional)</span> : null}
      </label>
      {hint ? (
        <p id={hintId} className="text-sm text-muted-dark">
          {hint}
        </p>
      ) : null}
      {children(describedBy)}
      {error ? (
        <p id={errorId} className="flex items-center gap-1.5 text-sm font-medium text-error" role="alert">
          <ErrorIcon />
          {error}
        </p>
      ) : null}
    </div>
  );
}

const inputBase =
  "h-12 w-full rounded border-2 bg-white px-4 text-base text-body-dark placeholder:text-muted-dark/70 transition-colors focus:outline-none";
const inputBorder = (hasError?: boolean) => (hasError ? "border-error" : "border-black/15 focus:border-ink");

export function TextInput({
  error,
  className,
  ...props
}: React.InputHTMLAttributes<HTMLInputElement> & { error?: string }) {
  return (
    <input
      className={cn(inputBase, inputBorder(!!error), className)}
      aria-invalid={error ? "true" : undefined}
      {...props}
    />
  );
}

export function TextArea({
  error,
  className,
  ...props
}: React.TextareaHTMLAttributes<HTMLTextAreaElement> & { error?: string }) {
  return (
    <textarea
      className={cn(
        "min-h-36 w-full rounded border-2 bg-white px-4 py-3 text-base text-body-dark placeholder:text-muted-dark/70 transition-colors focus:outline-none",
        inputBorder(!!error),
        className,
      )}
      aria-invalid={error ? "true" : undefined}
      {...props}
    />
  );
}

export function Select({
  error,
  className,
  children,
  ...props
}: React.SelectHTMLAttributes<HTMLSelectElement> & { error?: string }) {
  return (
    <div className="relative">
      <select
        className={cn(inputBase, inputBorder(!!error), "appearance-none pr-10", className)}
        aria-invalid={error ? "true" : undefined}
        {...props}
      >
        {children}
      </select>
      <svg
        aria-hidden="true"
        width="16"
        height="16"
        viewBox="0 0 16 16"
        fill="none"
        className="pointer-events-none absolute right-4 top-1/2 -translate-y-1/2"
      >
        <path d="M4 6l4 4 4-4" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    </div>
  );
}

export interface RadioCardOption {
  value: string;
  label: string;
}

export function RadioCardGroup({
  name,
  legend,
  options,
  value,
  onChange,
  error,
  required,
  hint,
  columns = 2,
}: {
  name: string;
  legend: string;
  options: RadioCardOption[];
  value: string;
  onChange: (value: string) => void;
  error?: string;
  required?: boolean;
  hint?: string;
  columns?: 2 | 4;
}) {
  const groupId = useId();
  const hintId = hint ? `${groupId}-hint` : undefined;
  const errorId = error ? `${groupId}-error` : undefined;
  const describedBy = [hintId, errorId].filter(Boolean).join(" ") || undefined;

  return (
    <fieldset aria-describedby={describedBy}>
      <legend className="font-body text-sm font-semibold text-body-dark">
        {legend}
        {required ? <span aria-hidden="true" className="ml-1 text-error">*</span> : null}
        {!required ? <span className="ml-1 font-normal text-muted-dark">(optional)</span> : null}
      </legend>
      {hint ? (
        <p id={hintId} className="mt-1 text-sm text-muted-dark">
          {hint}
        </p>
      ) : null}
      <div
        className={cn(
          "mt-2 grid gap-2",
          columns === 2 ? "grid-cols-1 sm:grid-cols-2" : "grid-cols-2 sm:grid-cols-4",
        )}
      >
        {options.map((option) => {
          const checked = value === option.value;
          return (
            <label
              key={option.value}
              className={cn(
                "flex cursor-pointer items-center justify-center rounded border-2 px-4 py-3 text-center text-sm font-semibold transition-colors",
                checked
                  ? "border-ink bg-ink text-yellow"
                  : "border-black/15 bg-white text-body-dark hover:border-ink/50",
              )}
            >
              <input
                type="radio"
                name={name}
                value={option.value}
                checked={checked}
                onChange={() => onChange(option.value)}
                className="sr-only"
              />
              {option.label}
            </label>
          );
        })}
      </div>
      {error ? (
        <p id={errorId} className="mt-2 flex items-center gap-1.5 text-sm font-medium text-error" role="alert">
          <ErrorIcon />
          {error}
        </p>
      ) : null}
    </fieldset>
  );
}

export function Checkbox({
  id,
  label,
  checked,
  onChange,
}: {
  id: string;
  label: React.ReactNode;
  checked: boolean;
  onChange: (checked: boolean) => void;
}) {
  return (
    <label htmlFor={id} className="flex cursor-pointer items-start gap-3 text-sm text-body-dark">
      <input
        id={id}
        type="checkbox"
        checked={checked}
        onChange={(e) => onChange(e.target.checked)}
        className="mt-1 h-5 w-5 shrink-0 rounded border-2 border-black/25 accent-ink"
      />
      <span>{label}</span>
    </label>
  );
}
