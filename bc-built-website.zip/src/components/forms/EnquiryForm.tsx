"use client";

import { useCallback, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { enquiryServiceOptions } from "@/content/services";
import { step1Schema, step2Schema, timingOptions, budgetOptions } from "@/lib/validation";
import { useConsent } from "@/components/consent/ConsentProvider";
import { FieldShell, TextInput, TextArea, Select, RadioCardGroup, Checkbox } from "@/components/forms/fields";
import { ErrorSummary, type ErrorSummaryItem } from "@/components/forms/ErrorSummary";
import { TurnstileWidget } from "@/components/forms/TurnstileWidget";
import { Button } from "@/components/ui/Button";

export type EnquirySource = "homepage" | "building" | "renovations" | "property-maintenance" | "contact" | "other";

interface FormState {
  service: string;
  postcode: string;
  description: string;
  timing: string;
  budget: string;
  name: string;
  email: string;
  phone: string;
  preferredReply: "Email" | "Phone";
  hasPhotos: boolean;
  company: string; // honeypot
}

const emptyState = (defaultService?: string): FormState => ({
  service: defaultService ?? "",
  postcode: "",
  description: "",
  timing: "",
  budget: "",
  name: "",
  email: "",
  phone: "",
  preferredReply: "Email",
  hasPhotos: false,
  company: "",
});

function newIdempotencyKey() {
  return typeof crypto !== "undefined" && "randomUUID" in crypto
    ? crypto.randomUUID()
    : `${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

export function EnquiryForm({ defaultService, source }: { defaultService?: string; source: EnquirySource }) {
  const router = useRouter();
  const { track } = useConsent();

  const [step, setStep] = useState<1 | 2>(1);
  const [values, setValues] = useState<FormState>(() => emptyState(defaultService));
  const [errors, setErrors] = useState<Partial<Record<keyof FormState, string>>>({});
  const [status, setStatus] = useState<"idle" | "submitting" | "error">("idle");
  const [serverMessage, setServerMessage] = useState<string | null>(null);
  const [turnstileToken, setTurnstileToken] = useState("");

  const idempotencyKey = useRef(newIdempotencyKey());
  const hasAttemptedSubmit = useRef(false);
  const hasStartedForm = useRef(false);

  const updateField = useCallback(<K extends keyof FormState>(key: K, value: FormState[K]) => {
    if (!hasStartedForm.current) {
      hasStartedForm.current = true;
      track("form_start", { service: defaultService });
    }
    setValues((prev) => {
      if (prev[key] === value) return prev;
      if (hasAttemptedSubmit.current) {
        idempotencyKey.current = newIdempotencyKey();
        hasAttemptedSubmit.current = false;
      }
      return { ...prev, [key]: value };
    });
    setErrors((prev) => (prev[key] ? { ...prev, [key]: undefined } : prev));
  }, [track, defaultService]);

  function goToStep2() {
    const result = step1Schema.safeParse({
      service: values.service,
      postcode: values.postcode,
      description: values.description,
      timing: values.timing,
      budget: values.budget,
    });
    if (!result.success) {
      const fieldErrors: Partial<Record<keyof FormState, string>> = {};
      for (const issue of result.error.issues) {
        const key = issue.path[0] as keyof FormState;
        if (!fieldErrors[key]) fieldErrors[key] = issue.message;
      }
      setErrors(fieldErrors);
      return;
    }
    setErrors({});
    setStep(2);
    track("form_step_complete", { step: 1, service: values.service });
  }

  function handleFormSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (step === 1) {
      goToStep2();
      return;
    }
    void submitEnquiry();
  }

  async function submitEnquiry() {
    const result = step2Schema.safeParse({
      name: values.name,
      email: values.email,
      phone: values.phone,
      preferredReply: values.preferredReply,
      hasPhotos: values.hasPhotos,
      company: values.company,
    });
    if (!result.success) {
      const fieldErrors: Partial<Record<keyof FormState, string>> = {};
      for (const issue of result.error.issues) {
        const key = issue.path[0] as keyof FormState;
        if (!fieldErrors[key]) fieldErrors[key] = issue.message;
      }
      setErrors(fieldErrors);
      return;
    }

    setStatus("submitting");
    setServerMessage(null);
    hasAttemptedSubmit.current = true;

    try {
      const response = await fetch("/api/enquiry", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...values,
          idempotencyKey: idempotencyKey.current,
          turnstileToken,
          source,
        }),
      });
      const data = await response.json();

      if (response.ok && data.ok) {
        track("form_submit_success", { service: values.service });
        router.push(`/thank-you?ref=${encodeURIComponent(data.reference)}`);
        return;
      }

      track("form_submit_failure", { reason: data.error ?? "unknown" });
      setStatus("error");
      setServerMessage(
        data.message ||
          "We could not send your enquiry just now. Your details are still here. Please try again, or email info@bcbuilt.co.uk.",
      );
    } catch {
      track("form_submit_failure", { reason: "network" });
      setStatus("error");
      setServerMessage(
        "We could not send your enquiry just now. Your details are still here. Please try again, or email info@bcbuilt.co.uk.",
      );
    }
  }

  const step1Errors: ErrorSummaryItem[] = (["service", "postcode", "description"] as const)
    .filter((key) => errors[key])
    .map((key) => ({ fieldId: `enquiry-${key}`, message: errors[key]! }));

  const step2Errors: ErrorSummaryItem[] = (["name", "email", "phone"] as const)
    .filter((key) => errors[key])
    .map((key) => ({ fieldId: `enquiry-${key}`, message: errors[key]! }));

  return (
    <form onSubmit={handleFormSubmit} noValidate>
      <p className="mb-1 font-display text-sm font-semibold uppercase tracking-[0.14em] text-muted-dark">
        {step === 1 ? "1 of 2 — Your project" : "2 of 2 — Your details"}
      </p>
      <div className="mb-6 h-1.5 w-full overflow-hidden rounded-full bg-black/10" role="progressbar" aria-valuenow={step} aria-valuemin={1} aria-valuemax={2} aria-label="Enquiry form progress">
        <div className="h-full bg-yellow transition-all duration-300" style={{ width: step === 1 ? "50%" : "100%" }} />
      </div>

      {/* Honeypot — hidden from sighted and assistive-tech users, never filled by a real visitor. Always present so a scripted submitter can't skip it by only inspecting step one. */}
      <div aria-hidden="true" className="absolute left-[-9999px] top-auto h-px w-px overflow-hidden">
        <label htmlFor="enquiry-company">Company</label>
        <input
          id="enquiry-company"
          name="company"
          type="text"
          tabIndex={-1}
          autoComplete="off"
          value={values.company}
          onChange={(e) => updateField("company", e.target.value)}
        />
      </div>

      {step === 1 ? (
        <div>
          <ErrorSummary items={step1Errors} />
          <div className="flex flex-col gap-6">
            <RadioCardGroup
              name="service"
              legend="Service required"
              required
              options={enquiryServiceOptions.map((o) => ({ value: o.value, label: o.label }))}
              value={values.service}
              onChange={(v) => updateField("service", v)}
              error={errors.service}
              columns={4}
            />

            <FieldShell label="Property postcode" required htmlFor="enquiry-postcode" error={errors.postcode}>
              {(describedBy) => (
                <TextInput
                  id="enquiry-postcode"
                  name="postcode"
                  autoComplete="postal-code"
                  placeholder="e.g. BN1 1AB"
                  value={values.postcode}
                  onChange={(e) => updateField("postcode", e.target.value)}
                  aria-describedby={describedBy}
                  error={errors.postcode}
                />
              )}
            </FieldShell>

            <FieldShell
              label="Tell us about the job"
              required
              htmlFor="enquiry-description"
              hint="At least 20 characters — what's the property and what would you like done?"
              error={errors.description}
            >
              {(describedBy) => (
                <>
                  <TextArea
                    id="enquiry-description"
                    name="description"
                    rows={5}
                    maxLength={2000}
                    value={values.description}
                    onChange={(e) => updateField("description", e.target.value)}
                    aria-describedby={describedBy}
                    error={errors.description}
                  />
                  <p className="text-right text-xs text-muted-dark">{values.description.length}/2000</p>
                </>
              )}
            </FieldShell>

            <FieldShell label="Preferred timing" htmlFor="enquiry-timing">
              {(describedBy) => (
                <Select
                  id="enquiry-timing"
                  name="timing"
                  value={values.timing}
                  onChange={(e) => updateField("timing", e.target.value)}
                  aria-describedby={describedBy}
                >
                  <option value="">Select an option</option>
                  {timingOptions.map((t) => (
                    <option key={t} value={t}>
                      {t}
                    </option>
                  ))}
                </Select>
              )}
            </FieldShell>

            <FieldShell
              label="Approximate budget"
              htmlFor="enquiry-budget"
              hint="This helps set expectations — it is not a fixed price or an eligibility limit."
            >
              {(describedBy) => (
                <Select
                  id="enquiry-budget"
                  name="budget"
                  value={values.budget}
                  onChange={(e) => updateField("budget", e.target.value)}
                  aria-describedby={describedBy}
                >
                  <option value="">Select an option</option>
                  {budgetOptions.map((b) => (
                    <option key={b} value={b}>
                      {b}
                    </option>
                  ))}
                </Select>
              )}
            </FieldShell>
          </div>

          <div className="mt-8 flex justify-end">
            <Button type="submit" showArrow>
              Continue
            </Button>
          </div>
        </div>
      ) : (
        <div>
          <ErrorSummary items={step2Errors} />

          <div className="flex flex-col gap-6">
            <FieldShell label="Full name" required htmlFor="enquiry-name" error={errors.name}>
              {(describedBy) => (
                <TextInput
                  id="enquiry-name"
                  name="name"
                  autoComplete="name"
                  value={values.name}
                  onChange={(e) => updateField("name", e.target.value)}
                  aria-describedby={describedBy}
                  error={errors.name}
                />
              )}
            </FieldShell>

            <FieldShell label="Email address" required htmlFor="enquiry-email" error={errors.email}>
              {(describedBy) => (
                <TextInput
                  id="enquiry-email"
                  name="email"
                  type="email"
                  inputMode="email"
                  autoComplete="email"
                  value={values.email}
                  onChange={(e) => updateField("email", e.target.value)}
                  aria-describedby={describedBy}
                  error={errors.email}
                />
              )}
            </FieldShell>

            <FieldShell
              label="Phone number"
              htmlFor="enquiry-phone"
              required={values.preferredReply === "Phone"}
              error={errors.phone}
            >
              {(describedBy) => (
                <TextInput
                  id="enquiry-phone"
                  name="phone"
                  type="tel"
                  inputMode="tel"
                  autoComplete="tel"
                  value={values.phone}
                  onChange={(e) => updateField("phone", e.target.value)}
                  aria-describedby={describedBy}
                  error={errors.phone}
                />
              )}
            </FieldShell>

            <RadioCardGroup
              name="preferredReply"
              legend="Preferred reply"
              required
              options={[
                { value: "Email", label: "Email" },
                { value: "Phone", label: "Phone" },
              ]}
              value={values.preferredReply}
              onChange={(v) => updateField("preferredReply", v as "Email" | "Phone")}
              columns={2}
            />

            <Checkbox
              id="enquiry-hasPhotos"
              checked={values.hasPhotos}
              onChange={(checked) => updateField("hasPhotos", checked)}
              label="I have photos or plans I can email"
            />

            <p className="text-sm text-muted-dark">
              We will use these details to respond to your enquiry. Read our{" "}
              <Link href="/privacy" className="underline decoration-2 underline-offset-2 hover:decoration-ink">
                privacy notice
              </Link>
              .
            </p>

            <TurnstileWidget onToken={setTurnstileToken} />
          </div>

          {status === "error" && serverMessage ? (
            <div role="alert" className="mt-6 rounded border-2 border-error bg-error-bg px-5 py-4 text-sm font-medium text-error">
              {serverMessage}
            </div>
          ) : null}

          <div className="mt-8 flex flex-col-reverse gap-3 sm:flex-row sm:justify-between">
            <Button type="button" variant="secondary" onClick={() => setStep(1)} disabled={status === "submitting"}>
              Back
            </Button>
            <Button type="submit" disabled={status === "submitting"} showArrow>
              {status === "submitting" ? "Sending…" : "Send project enquiry"}
            </Button>
          </div>
        </div>
      )}
    </form>
  );
}
