"use client";

import { useEffect, useRef } from "react";

export interface ErrorSummaryItem {
  fieldId: string;
  message: string;
}

export function ErrorSummary({ items, title = "There is a problem" }: { items: ErrorSummaryItem[]; title?: string }) {
  const headingRef = useRef<HTMLHeadingElement>(null);

  useEffect(() => {
    if (items.length > 0) headingRef.current?.focus();
  }, [items]);

  if (items.length === 0) return null;

  return (
    <div
      role="alert"
      aria-labelledby="error-summary-title"
      tabIndex={-1}
      className="mb-6 rounded border-2 border-error bg-error-bg px-5 py-4"
    >
      <h2 id="error-summary-title" ref={headingRef} tabIndex={-1} className="font-display text-lg font-bold uppercase tracking-wide text-error focus:outline-none">
        {title}
      </h2>
      <ul className="mt-3 space-y-1.5">
        {items.map((item) => (
          <li key={item.fieldId}>
            <a
              href={`#${item.fieldId}`}
              onClick={(e) => {
                e.preventDefault();
                const el = document.getElementById(item.fieldId);
                el?.focus();
                el?.scrollIntoView({ block: "center", behavior: "smooth" });
              }}
              className="text-sm font-semibold text-error underline underline-offset-2 hover:no-underline"
            >
              {item.message}
            </a>
          </li>
        ))}
      </ul>
    </div>
  );
}
