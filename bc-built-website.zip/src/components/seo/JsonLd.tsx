import { business } from "@/content/business";
import { getSiteUrl } from "@/lib/env";

/**
 * Structured data kept deliberately minimal and honest: only fields backed
 * by a verified fact are included. No street address (none confirmed — see
 * LAUNCH-CHECKLIST.md; this also means LocalBusiness rich-result eligibility
 * is not attempted), no aggregateRating, no invented opening hours, no
 * unverified sameAs profile links.
 */
export function OrganizationJsonLd() {
  const siteUrl = getSiteUrl();
  const data = {
    "@context": "https://schema.org",
    "@type": "Organization",
    name: business.name,
    url: siteUrl,
    logo: `${siteUrl}/images/logo/bc-built-logo.png`,
    email: business.email,
    telephone: business.phoneInternationalDisplay,
    contactPoint: [
      {
        "@type": "ContactPoint",
        contactType: "customer service",
        email: business.email,
        telephone: business.phoneInternationalDisplay,
        areaServed: "GB",
        availableLanguage: ["en-GB"],
      },
    ],
  };
  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  );
}

export function WebSiteJsonLd() {
  const siteUrl = getSiteUrl();
  const data = {
    "@context": "https://schema.org",
    "@type": "WebSite",
    name: business.name,
    url: siteUrl,
    inLanguage: "en-GB",
  };
  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  );
}

export function BreadcrumbJsonLd({ items }: { items: { name: string; path: string }[] }) {
  const siteUrl = getSiteUrl();
  const data = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: items.map((item, index) => ({
      "@type": "ListItem",
      position: index + 1,
      name: item.name,
      item: `${siteUrl}${item.path}`,
    })),
  };
  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  );
}

export function ServiceJsonLd({ name, description, path }: { name: string; description: string; path: string }) {
  const siteUrl = getSiteUrl();
  const data = {
    "@context": "https://schema.org",
    "@type": "Service",
    name,
    description,
    url: `${siteUrl}${path}`,
    provider: {
      "@type": "Organization",
      name: business.name,
    },
    areaServed: ["Brighton & Hove", "Sussex"],
  };
  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  );
}
