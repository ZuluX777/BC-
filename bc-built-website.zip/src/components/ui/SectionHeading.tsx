import { cn } from "@/lib/cn";
import { Rule } from "@/components/ui/Rule";

export function SectionHeading({
  eyebrow,
  title,
  align = "left",
  className,
  titleClassName,
}: {
  eyebrow?: string;
  title: string;
  align?: "left" | "center";
  className?: string;
  titleClassName?: string;
}) {
  return (
    <div className={cn(align === "center" && "text-center", className)}>
      {eyebrow ? (
        <p className="mb-2 font-display text-sm font-semibold uppercase tracking-[0.14em] text-muted-dark">
          {eyebrow}
        </p>
      ) : null}
      <h2 className={cn("text-3xl md:text-4xl lg:text-[2.75rem]", titleClassName)}>{title}</h2>
      <Rule className={cn("mt-4", align === "center" && "mx-auto")} />
    </div>
  );
}
