import { cn } from "@/lib/cn";

export function Rule({ className }: { className?: string }) {
  return <div className={cn("h-[3px] w-16 bg-yellow", className)} aria-hidden="true" />;
}
