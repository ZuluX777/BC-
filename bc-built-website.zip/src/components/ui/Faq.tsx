import type { Faq as FaqItem } from "@/content/faqs";

export function FaqList({ items }: { items: FaqItem[] }) {
  return (
    <div className="divide-y divide-black/10">
      {items.map((item) => (
        <details key={item.question} className="group py-5">
          <summary className="flex cursor-pointer list-none items-center justify-between gap-4 font-display text-lg font-semibold uppercase tracking-wide text-body-dark marker:content-none [&::-webkit-details-marker]:hidden">
            <span>{item.question}</span>
            <svg
              aria-hidden="true"
              width="20"
              height="20"
              viewBox="0 0 20 20"
              fill="none"
              className="shrink-0 transition-transform duration-200 group-open:rotate-45"
            >
              <path d="M10 4v12M4 10h12" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
            </svg>
          </summary>
          <p className="mt-3 max-w-[65ch] font-body text-base leading-relaxed text-muted-dark">
            {item.answer}
          </p>
        </details>
      ))}
    </div>
  );
}
