import Link from "next/link";
import { cn } from "@/lib/cn";

type Variant = "primary" | "secondary" | "ghost";
type Size = "sm" | "md" | "lg";

const base =
  "group inline-flex items-center justify-center gap-2 rounded font-body font-semibold transition-[background-color,transform,border-color,color] duration-[180ms] ease-out active:translate-y-0 disabled:cursor-not-allowed disabled:opacity-60";

const variants: Record<Variant, string> = {
  primary: "bg-yellow text-ink hover:bg-yellow-hover hover:-translate-y-px",
  secondary:
    "border-2 border-current bg-transparent hover:-translate-y-px hover:bg-yellow hover:text-ink hover:border-yellow",
  ghost: "bg-transparent underline decoration-2 underline-offset-4 decoration-transparent hover:decoration-current",
};

const sizes: Record<Size, string> = {
  sm: "h-10 px-4 text-sm",
  md: "h-12 px-6 text-base md:h-13",
  lg: "h-13 px-8 text-base md:h-[52px] md:px-9 md:text-lg",
};

interface CommonProps {
  variant?: Variant;
  size?: Size;
  className?: string;
  showArrow?: boolean;
  children: React.ReactNode;
}

type ButtonAsButton = CommonProps &
  React.ButtonHTMLAttributes<HTMLButtonElement> & { href?: undefined };

type ButtonAsLink = CommonProps &
  Omit<React.AnchorHTMLAttributes<HTMLAnchorElement>, "href"> & { href: string };

export type ButtonProps = ButtonAsButton | ButtonAsLink;

function Arrow() {
  return (
    <svg
      aria-hidden="true"
      width="18"
      height="18"
      viewBox="0 0 18 18"
      fill="none"
      className="shrink-0 transition-transform duration-[180ms] ease-out group-hover:translate-x-[3px]"
    >
      <path d="M3 9h11.5M10 4.5 15 9l-5 4.5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function Button({ variant = "primary", size = "md", className, showArrow, children, ...props }: ButtonProps) {
  const classes = cn(base, variants[variant], sizes[size], className);

  if ("href" in props && props.href) {
    const { href, ...anchorProps } = props;
    return (
      <Link href={href} className={classes} {...anchorProps}>
        {children}
        {showArrow ? <Arrow /> : null}
      </Link>
    );
  }

  const { type = "button", ...buttonProps } = props as ButtonAsButton;
  return (
    <button type={type} className={classes} {...buttonProps}>
      {children}
      {showArrow ? <Arrow /> : null}
    </button>
  );
}
