import { cn } from "@/lib/cn";

export function Eyebrow({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <p
      className={cn(
        "font-display text-sm font-semibold uppercase tracking-[0.14em] text-yellow",
        className,
      )}
    >
      {children}
    </p>
  );
}
