import { cn } from "@/lib/cn";

export function Container({
  className,
  children,
  as: Component = "div",
}: {
  className?: string;
  children: React.ReactNode;
  as?: React.ElementType;
}) {
  return (
    <Component className={cn("mx-auto w-full max-w-(--max-content) px-(--gutter)", className)}>
      {children}
    </Component>
  );
}
