import { cn } from "@/lib/cn";

// Intrinsic size of the trimmed logo asset — declared so the browser can
// reserve layout space and avoid shift, regardless of the rendered CSS size.
const INTRINSIC_WIDTH = 1551;
const INTRINSIC_HEIGHT = 783;

export function Logo({ className, priority = false }: { className?: string; priority?: boolean }) {
  return (
    // The <picture> element has no intrinsic size of its own — without an
    // explicit height here, the <img>'s h-full (100%) below has no defined
    // ancestor height to resolve against and the browser falls back to
    // rendering it near its natural intrinsic size (1551x783) instead of
    // the intended height, blowing out the layout. "block" alone gives the
    // caller-supplied height class in `className` (h-14, h-full, h-20
    // md:h-24, etc.) a real basis to resolve against — it is NOT hardcoded
    // here too, since a second, conflicting height utility in the same
    // class list would fight the caller's intended size.
    <picture className={cn("block", className)}>
      <source srcSet="/images/logo/bc-built-logo.webp" type="image/webp" />
      <img
        src="/images/logo/bc-built-logo.png"
        width={INTRINSIC_WIDTH}
        height={INTRINSIC_HEIGHT}
        alt="BC Built — Building, Renovations, Property Maintenance — Brighton & Hove, Sussex"
        className="h-full w-auto object-contain"
        loading={priority ? "eager" : "lazy"}
        fetchPriority={priority ? "high" : "auto"}
        decoding="async"
      />
    </picture>
  );
}
