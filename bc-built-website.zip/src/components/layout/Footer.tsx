"use client";

import Link from "next/link";
import { business } from "@/content/business";
import { primaryNav, workNavLink } from "@/content/nav";
import { verifiedProjects } from "@/content/projects";
import { Logo } from "@/components/layout/Logo";
import { Container } from "@/components/ui/Container";
import { CookiePreferencesButton } from "@/components/consent/CookieConsent";
import { useConsent } from "@/components/consent/ConsentProvider";

export function Footer() {
  const { track } = useConsent();
  const year = new Date().getFullYear();
  const links = verifiedProjects.length > 0 ? [...primaryNav, workNavLink] : primaryNav;

  return (
    <footer className="bg-ink text-body-light">
      <Container className="py-14">
        <div className="grid gap-10 md:grid-cols-[1.2fr_1fr_1fr]">
          <div>
            <Logo className="h-14" />
            <p className="mt-5 max-w-xs text-sm leading-relaxed">
              Building, renovations and property maintenance in Brighton & Hove and Sussex.
            </p>
          </div>

          <div>
            <h2 className="font-display text-sm font-semibold uppercase tracking-[0.14em] text-yellow">
              Contact
            </h2>
            <ul className="mt-4 space-y-2 text-sm">
              <li>
                <a
                  href={`mailto:${business.email}`}
                  onClick={() => track("email_click", { placement: "footer" })}
                  className="hover:text-yellow"
                >
                  {business.email}
                </a>
              </li>
              <li>
                <a
                  href={`tel:${business.phoneHref}`}
                  onClick={() => track("phone_click", { placement: "footer" })}
                  className="hover:text-yellow"
                >
                  {business.phoneDisplay}
                </a>
              </li>
              <li>{business.locationLabel}</li>
            </ul>
          </div>

          <div>
            <h2 className="font-display text-sm font-semibold uppercase tracking-[0.14em] text-yellow">
              Site
            </h2>
            <ul className="mt-4 space-y-2 text-sm">
              {links.map((link) => (
                <li key={link.href}>
                  <Link href={link.href} className="hover:text-yellow">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-12 flex flex-col gap-4 border-t border-white/10 pt-6 text-xs text-body-light/80 md:flex-row md:items-center md:justify-between">
          <p>
            &copy; {year} {business.name}. {business.director}, {business.directorTitle}.
          </p>
          <div className="flex flex-wrap items-center gap-x-6 gap-y-2">
            <Link href="/privacy" className="hover:text-yellow">
              Privacy notice
            </Link>
            <Link href="/terms" className="hover:text-yellow">
              Terms of use
            </Link>
            <Link href="/cookies" className="hover:text-yellow">
              Cookies
            </Link>
            <CookiePreferencesButton />
          </div>
        </div>
      </Container>
    </footer>
  );
}
