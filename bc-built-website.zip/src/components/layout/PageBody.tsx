"use client";

import { usePathname } from "next/navigation";
import { mobileCtaHiddenRoutes } from "@/content/nav";
import { cn } from "@/lib/cn";

export function PageBody({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const reserveMobileCtaSpace = !mobileCtaHiddenRoutes.some((path) => pathname.startsWith(path));

  return (
    <main id="main-content" className={cn(reserveMobileCtaSpace && "pb-[88px] md:pb-0")}>
      {children}
    </main>
  );
}
