"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { primaryNav, primaryCtaLabel, workNavLink } from "@/content/nav";
import { verifiedProjects } from "@/content/projects";
import { Logo } from "@/components/layout/Logo";
import { MobileMenu } from "@/components/layout/MobileMenu";
import { Button } from "@/components/ui/Button";
import { Container } from "@/components/ui/Container";

export function Header() {
  const pathname = usePathname();
  const links = verifiedProjects.length > 0 ? [...primaryNav, workNavLink] : primaryNav;

  return (
    <header className="sticky top-0 z-30 h-[72px] bg-ink md:h-[88px]">
      <Container className="flex h-full items-center justify-between">
        <Link href="/" className="flex h-9 items-center md:h-11" aria-label="BC Built home">
          <Logo priority className="h-full" />
        </Link>

        <nav aria-label="Primary" className="hidden items-center gap-8 md:flex">
          {links.map((link) => {
            const current = pathname === link.href || (link.href !== "/" && pathname.startsWith(link.href));
            return (
              <Link
                key={link.href}
                href={link.href}
                aria-current={current ? "page" : undefined}
                className="relative py-2 font-body text-sm font-semibold uppercase tracking-wide text-white transition-colors hover:text-yellow after:absolute after:-bottom-0.5 after:left-0 after:h-[2px] after:w-full after:origin-left after:scale-x-0 after:bg-yellow after:transition-transform after:duration-200 hover:after:scale-x-100 aria-[current=page]:text-yellow aria-[current=page]:after:scale-x-100"
              >
                {link.label}
              </Link>
            );
          })}
        </nav>

        <div className="hidden md:block">
          <Button href="/contact" size="md" showArrow>
            {primaryCtaLabel}
          </Button>
        </div>

        <MobileMenu />
      </Container>
    </header>
  );
}
