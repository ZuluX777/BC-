"use client";

import { usePathname } from "next/navigation";
import { business } from "@/content/business";
import { primaryCtaLabel, mobileCtaHiddenRoutes } from "@/content/nav";
import { Button } from "@/components/ui/Button";
import { useConsent } from "@/components/consent/ConsentProvider";

export function MobileCta() {
  const pathname = usePathname();
  const { track } = useConsent();

  if (mobileCtaHiddenRoutes.some((path) => pathname.startsWith(path))) return null;

  return (
    <div
      className="flex items-center gap-3 border-t border-black/10 bg-white px-4 py-3 md:hidden"
      style={{ paddingBottom: "calc(0.75rem + env(safe-area-inset-bottom))" }}
    >
      <Button href="/contact" className="flex-1" size="md">
        {primaryCtaLabel}
      </Button>
      <a
        href={`tel:${business.phoneHref}`}
        onClick={() => track("phone_click", { placement: "mobile_bar" })}
        aria-label={`Call BC Built on ${business.phoneDisplay}`}
        className="inline-flex h-12 w-12 shrink-0 items-center justify-center rounded border-2 border-ink text-ink"
      >
        <svg aria-hidden="true" width="20" height="20" viewBox="0 0 20 20" fill="none">
          <path
            d="M4 3h3l1.5 4-2 1.3a9 9 0 0 0 4.2 4.2l1.3-2 4 1.5v3a1 1 0 0 1-1 1C9.6 16 4 10.4 4 4a1 1 0 0 1 0-1Z"
            stroke="currentColor"
            strokeWidth="1.4"
            strokeLinejoin="round"
          />
        </svg>
      </a>
    </div>
  );
}
