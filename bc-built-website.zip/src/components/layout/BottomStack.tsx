"use client";

import { CookieConsent } from "@/components/consent/CookieConsent";
import { MobileCta } from "@/components/layout/MobileCta";

/**
 * Fixed bottom stack. Cookie consent (when shown) renders above the mobile
 * CTA bar — normal flex flow, so the two never overlap and neither needs to
 * know about the other's height.
 */
export function BottomStack() {
  return (
    <div className="fixed inset-x-0 bottom-0 z-40 flex flex-col">
      <CookieConsent />
      <MobileCta />
    </div>
  );
}
