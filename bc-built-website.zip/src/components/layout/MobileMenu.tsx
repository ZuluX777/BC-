"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { primaryNav, primaryCtaLabel, workNavLink } from "@/content/nav";
import { business } from "@/content/business";
import { verifiedProjects } from "@/content/projects";
import { Button } from "@/components/ui/Button";

const FOCUSABLE_SELECTOR =
  'a[href], button:not([disabled]), textarea, input, select, [tabindex]:not([tabindex="-1"])';

export function MobileMenu() {
  const [open, setOpen] = useState(false);
  const pathname = usePathname();
  const panelRef = useRef<HTMLDivElement>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);
  const closeRef = useRef<HTMLButtonElement>(null);

  const links = verifiedProjects.length > 0 ? [...primaryNav, workNavLink] : primaryNav;

  // Close the menu on navigation. Adjusted during render (not in an effect)
  // per https://react.dev/learn/you-might-not-need-an-effect#adjusting-some-state-when-a-prop-changes
  // so there is no extra render where a stale menu is still shown open.
  const [previousPathname, setPreviousPathname] = useState(pathname);
  if (pathname !== previousPathname) {
    setPreviousPathname(pathname);
    if (open) setOpen(false);
  }

  useEffect(() => {
    if (!open) return;

    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    closeRef.current?.focus();

    function onKeyDown(e: KeyboardEvent) {
      if (e.key === "Escape") {
        close();
        return;
      }
      if (e.key !== "Tab" || !panelRef.current) return;
      const focusable = Array.from(panelRef.current.querySelectorAll<HTMLElement>(FOCUSABLE_SELECTOR)).filter(
        (el) => el.offsetParent !== null,
      );
      if (focusable.length === 0) return;
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    }

    document.addEventListener("keydown", onKeyDown);
    return () => {
      document.removeEventListener("keydown", onKeyDown);
      document.body.style.overflow = previousOverflow;
    };
  }, [open]);

  function close() {
    setOpen(false);
    triggerRef.current?.focus();
  }

  return (
    <>
      <button
        ref={triggerRef}
        type="button"
        onClick={() => setOpen(true)}
        aria-expanded={open}
        aria-controls="mobile-menu-panel"
        className="inline-flex items-center gap-2 rounded px-2 py-2 font-display text-sm font-semibold uppercase tracking-wide text-white md:hidden"
      >
        <span>Menu</span>
        <svg aria-hidden="true" width="24" height="24" viewBox="0 0 24 24" fill="none">
          <path d="M4 7h16M4 12h16M4 17h16" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
        </svg>
      </button>

      {open ? (
        <div className="fixed inset-0 z-50 md:hidden">
          <div className="absolute inset-0 bg-ink/70" onClick={close} aria-hidden="true" />
          <div
            id="mobile-menu-panel"
            ref={panelRef}
            role="dialog"
            aria-modal="true"
            aria-label="Site menu"
            className="absolute inset-y-0 right-0 flex w-full max-w-sm flex-col bg-ink px-6 py-6 text-white shadow-2xl"
          >
            <div className="flex items-center justify-between">
              <span className="font-display text-lg font-bold uppercase tracking-wide text-yellow">Menu</span>
              <button
                ref={closeRef}
                type="button"
                onClick={close}
                aria-label="Close menu"
                className="rounded p-2"
              >
                <svg aria-hidden="true" width="26" height="26" viewBox="0 0 26 26" fill="none">
                  <path d="M6 6l14 14M20 6 6 20" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
                </svg>
              </button>
            </div>

            <nav aria-label="Mobile" className="mt-10 flex flex-col gap-1">
              {links.map((link) => {
                const current = pathname === link.href || (link.href !== "/" && pathname.startsWith(link.href));
                return (
                  <Link
                    key={link.href}
                    href={link.href}
                    aria-current={current ? "page" : undefined}
                    className="border-b border-white/10 py-4 font-display text-2xl font-semibold uppercase tracking-wide text-white hover:text-yellow focus-visible:text-yellow"
                  >
                    {link.label}
                  </Link>
                );
              })}
            </nav>

            <div className="mt-8">
              <Button href="/contact" size="lg" className="w-full">
                {primaryCtaLabel}
              </Button>
            </div>

            <div className="mt-auto flex flex-col gap-3 pt-8 text-sm text-body-light">
              <a href={`tel:${business.phoneHref}`} className="hover:text-yellow">
                Call {business.phoneDisplay}
              </a>
              <a href={`mailto:${business.email}`} className="hover:text-yellow">
                Email {business.email}
              </a>
            </div>
          </div>
        </div>
      ) : null}
    </>
  );
}
