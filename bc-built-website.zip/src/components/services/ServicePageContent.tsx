import type { Service } from "@/content/services";
import { verifiedProjects } from "@/content/projects";
import { homeFaqs } from "@/content/faqs";
import { contactHrefForService } from "@/lib/enquiry-link";
import { Container } from "@/components/ui/Container";
import { Eyebrow } from "@/components/ui/Eyebrow";
import { Rule } from "@/components/ui/Rule";
import { Button } from "@/components/ui/Button";
import { FaqList } from "@/components/ui/Faq";
import { BreadcrumbJsonLd, ServiceJsonLd } from "@/components/seo/JsonLd";

export function ServicePageContent({ service }: { service: Service }) {
  const relatedProjects = verifiedProjects.filter((p) => p.service === service.enquiryValue);

  return (
    <>
      <BreadcrumbJsonLd
        items={[
          { name: "Home", path: "/" },
          { name: "Services", path: "/services" },
          { name: service.cardTitle, path: `/services/${service.slug}` },
        ]}
      />
      <ServiceJsonLd name={service.cardTitle} description={service.metaDescription} path={`/services/${service.slug}`} />

      <section className="bg-ink py-14 text-white md:py-20">
        <Container>
          <Eyebrow>Services</Eyebrow>
          <h1 className="mt-2 max-w-2xl text-4xl md:text-5xl">{service.h1}</h1>
          <Rule className="mt-5" />
          <p className="mt-6 max-w-xl text-base leading-relaxed text-body-light md:text-lg">{service.intro}</p>
          <div className="mt-8">
            <Button href={contactHrefForService(service.enquiryValue)} showArrow>
              {service.ctaLabel}
            </Button>
          </div>
        </Container>
      </section>

      <section className="bg-white py-14 md:py-20">
        <Container className="max-w-3xl">
          <h2 className="text-2xl md:text-3xl">{service.usefulDetailsHeading}</h2>
          <ul className="mt-6 space-y-3">
            {service.usefulDetails.map((detail) => (
              <li key={detail.label} className="flex items-start gap-3 text-base text-body-dark">
                <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-yellow" aria-hidden="true" />
                {detail.label}
              </li>
            ))}
          </ul>
        </Container>
      </section>

      {relatedProjects.length > 0 ? (
        <section className="bg-paper py-14 md:py-20">
          <Container>
            <h2 className="text-2xl md:text-3xl">Recent {service.cardTitle.toLowerCase()} work</h2>
            <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {relatedProjects.map((project) => (
                <a key={project.slug} href={`/projects/${project.slug}`} className="block rounded border border-black/10 bg-white p-5 hover:border-ink">
                  <p className="font-display text-xs font-semibold uppercase tracking-wide text-muted-dark">
                    {project.locationLabel}
                  </p>
                  <h3 className="mt-1 text-lg">{project.title}</h3>
                </a>
              ))}
            </div>
          </Container>
        </section>
      ) : null}

      <section className="bg-white py-14 md:py-20">
        <Container className="max-w-3xl">
          <h2 className="text-2xl md:text-3xl">Frequently asked questions</h2>
          <div className="mt-6">
            <FaqList items={homeFaqs} />
          </div>
        </Container>
      </section>

      <section className="bg-ink py-14 text-white md:py-16">
        <Container className="flex flex-col items-start gap-6 md:flex-row md:items-center md:justify-between">
          <h2 className="text-2xl md:text-3xl">Ready to talk about your project?</h2>
          <Button href={contactHrefForService(service.enquiryValue)} showArrow>
            {service.ctaLabel}
          </Button>
        </Container>
      </section>
    </>
  );
}
