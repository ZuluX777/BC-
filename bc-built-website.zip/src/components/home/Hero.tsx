import Link from "next/link";
import { business } from "@/content/business";
import { Button } from "@/components/ui/Button";
import { Container } from "@/components/ui/Container";
import { HeroGraphic } from "@/components/home/HeroGraphic";
import { verifiedProjects } from "@/content/projects";

export function Hero() {
  return (
    <section className="bg-ink text-white">
      <Container className="grid gap-10 py-12 md:grid-cols-2 md:items-center md:gap-8 md:py-20 lg:grid-cols-[0.46fr_0.54fr] lg:gap-12">
        <div className="reveal order-2 md:order-1">
          <p className="mb-4 inline-flex items-center gap-2 rounded-full border border-yellow/40 px-3 py-1 font-display text-xs font-semibold uppercase tracking-[0.16em] text-yellow">
            {business.locationLabel}
          </p>
          <p className="font-display text-sm font-semibold uppercase tracking-[0.18em] text-body-light">
            {business.tagline}
          </p>
          <h1 className="mt-3 text-[2.6rem] leading-[1.03] md:text-5xl lg:text-[3.4rem]">
            Building &amp; renovations in Brighton &amp; Hove.
          </h1>
          <div className="mt-5 h-[3px] w-16 bg-yellow" aria-hidden="true" />
          <p className="mt-6 max-w-md text-base leading-relaxed text-body-light md:text-lg">
            Planning a renovation or need work carried out on your property? Tell BC Built what you have in mind.
            Contact Brandon to discuss your project in Brighton, Hove or Sussex.
          </p>
          <div className="mt-8 flex flex-wrap items-center gap-x-6 gap-y-4">
            <Button href="/contact" size="lg" showArrow>
              Tell us about your project
            </Button>
            <a href={`mailto:${business.email}`} className="text-sm font-semibold text-body-light underline decoration-yellow/60 decoration-2 underline-offset-4 hover:text-yellow">
              Prefer email? {business.email}
            </a>
          </div>
          {verifiedProjects.length > 0 ? (
            <Link href="/projects" className="mt-6 inline-block text-sm font-semibold text-body-light underline underline-offset-4 hover:text-yellow">
              View our work
            </Link>
          ) : null}
        </div>
        <div className="order-1 md:order-2">
          <HeroGraphic />
        </div>
      </Container>
    </section>
  );
}
