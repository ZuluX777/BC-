/**
 * Intentional geometric hero composition, built from the brand's own
 * roofline/diagonal language, used because no owner-approved project
 * photography exists yet for this new business. Not a placeholder — a
 * deliberate design choice per the build brief ("polished geometric hero
 * fallback"). Swap for real project photography in content/projects.ts /
 * a future hero image prop once supplied.
 */
export function HeroGraphic() {
  return (
    <div className="relative aspect-[4/5] w-full overflow-hidden rounded md:aspect-[3/4] lg:aspect-[4/5]" aria-hidden="true">
      <svg viewBox="0 0 400 500" className="h-full w-full" preserveAspectRatio="xMidYMid slice">
        <rect width="400" height="500" fill="#20221F" />
        <polygon points="0,500 0,320 200,140 400,320 400,500" fill="#101110" />
        <polygon points="60,500 60,360 200,230 340,360 340,500" fill="#181917" />
        <polygon points="200,140 400,320 400,140" fill="#F7C600" opacity="0.9" />
        <polygon points="0,320 200,140 0,140" fill="#FFDA33" opacity="0.15" />
        <rect x="170" y="260" width="60" height="60" fill="#20221F" />
        <rect x="184" y="274" width="14" height="14" fill="#F7C600" />
        <rect x="202" y="274" width="14" height="14" fill="#F7C600" />
        <rect x="184" y="292" width="14" height="14" fill="#F7C600" />
        <rect x="202" y="292" width="14" height="14" fill="#F7C600" />
        <line x1="0" y1="320" x2="400" y2="320" stroke="#F7C600" strokeWidth="3" />
        <line x1="200" y1="140" x2="200" y2="500" stroke="#F7C600" strokeOpacity="0.25" strokeWidth="1" />
      </svg>
    </div>
  );
}
