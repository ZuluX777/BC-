import Link from "next/link";
import { services } from "@/content/services";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { Container } from "@/components/ui/Container";

export function ServicesSection() {
  return (
    <section className="bg-paper py-16 md:py-24">
      <Container>
        <SectionHeading title="What does your property need?" />
        <div className="mt-10 divide-y divide-black/10 border-t border-black/10">
          {services.map((service, index) => (
            <Link
              key={service.slug}
              href={`/services/${service.slug}`}
              className="group flex flex-col gap-4 py-8 transition-colors hover:bg-white md:flex-row md:items-center md:gap-8 md:px-4"
            >
              {/* Decorative index numeral — redundant with the heading below,
                  so aria-hidden from assistive tech. aria-hidden alone does
                  NOT satisfy WCAG 1.4.3 though: a sighted low-vision visitor
                  still sees this text, so it still needs real contrast.
                  black/45 measures ~3.2:1 against both the paper and white
                  section backgrounds here — the 3:1 minimum for large bold
                  text — while staying a quiet accent rather than full-weight
                  body text. */}
              <span aria-hidden="true" className="font-display text-5xl font-bold text-black/45 md:w-24 md:text-6xl">
                {String(index + 1).padStart(2, "0")}
              </span>
              <div className="flex-1">
                <h3 className="text-2xl md:text-[1.75rem]">{service.cardTitle}</h3>
                <p className="mt-2 max-w-xl text-base leading-relaxed text-muted-dark">{service.cardBody}</p>
              </div>
              <span className="flex shrink-0 items-center gap-2 font-body text-sm font-semibold text-body-dark underline decoration-yellow decoration-2 underline-offset-4 group-hover:text-ink">
                {service.cardLinkLabel}
                <svg aria-hidden="true" width="16" height="16" viewBox="0 0 16 16" fill="none" className="transition-transform duration-200 group-hover:translate-x-1">
                  <path d="M2 8h11M9 4l4 4-4 4" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </span>
            </Link>
          ))}
        </div>
      </Container>
    </section>
  );
}
