import Image from "next/image";
import Link from "next/link";
import { verifiedProjects } from "@/content/projects";
import { Container } from "@/components/ui/Container";
import { SectionHeading } from "@/components/ui/SectionHeading";

/**
 * Renders nothing when there are no verified project entries — per the
 * build brief, an empty portfolio must never appear as a public section.
 */
export function WorkSection() {
  if (verifiedProjects.length === 0) return null;

  const featured = verifiedProjects.find((p) => p.featured) ?? verifiedProjects[0];
  const rest = verifiedProjects.filter((p) => p.slug !== featured.slug).slice(0, 2);

  return (
    <section className="bg-white py-16 md:py-24">
      <Container>
        <SectionHeading title="A closer look at the work." />
        <div className="mt-10 grid gap-6 lg:grid-cols-2">
          <Link href={`/projects/${featured.slug}`} className="group relative block overflow-hidden rounded lg:row-span-2">
            <div className="relative aspect-[4/3]">
              <Image
                src={featured.coverImage}
                alt={featured.coverImageAlt}
                fill
                className="object-cover transition-transform duration-300 group-hover:scale-[1.02]"
              />
            </div>
            <div className="border border-t-0 border-black/10 p-6">
              <p className="font-display text-sm font-semibold uppercase tracking-wide text-muted-dark">
                {featured.locationLabel} · {featured.service}
              </p>
              <h3 className="mt-1 text-2xl">{featured.title}</h3>
            </div>
          </Link>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-1">
            {rest.map((project) => (
              <Link key={project.slug} href={`/projects/${project.slug}`} className="group block overflow-hidden rounded">
                <div className="relative aspect-[4/3]">
                  <Image
                    src={project.coverImage}
                    alt={project.coverImageAlt}
                    fill
                    className="object-cover transition-transform duration-300 group-hover:scale-[1.02]"
                  />
                </div>
                <div className="border border-t-0 border-black/10 p-4">
                  <p className="font-display text-xs font-semibold uppercase tracking-wide text-muted-dark">
                    {project.locationLabel}
                  </p>
                  <h3 className="mt-1 text-lg">{project.title}</h3>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </Container>
    </section>
  );
}
