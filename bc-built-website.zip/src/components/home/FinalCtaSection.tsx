import { Container } from "@/components/ui/Container";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { EnquiryForm } from "@/components/forms/EnquiryForm";

export function FinalCtaSection() {
  return (
    <section id="enquire" className="bg-paper py-16 md:py-24">
      <Container className="grid gap-10 lg:grid-cols-[0.9fr_1.1fr] lg:gap-16">
        <div>
          <SectionHeading title="Tell us what you have in mind." />
          <p className="mt-6 max-w-md text-base leading-relaxed text-muted-dark md:text-lg">
            A few details are enough to start the conversation. Tell Brandon where the property is and what you would
            like done.
          </p>
        </div>
        <div className="rounded border border-black/10 bg-white p-6 shadow-sm md:p-10">
          <EnquiryForm source="homepage" />
        </div>
      </Container>
    </section>
  );
}
