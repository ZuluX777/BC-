import { processSteps } from "@/content/process";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { Container } from "@/components/ui/Container";

export function ProcessSection() {
  return (
    <section className="bg-white py-16 md:py-24">
      <Container>
        <SectionHeading title="Start with a few details." />
        <ol className="mt-10 grid gap-8 md:grid-cols-3 md:gap-10">
          {processSteps.map((step) => (
            <li key={step.step} className="relative border-t-4 border-yellow pt-6">
              {/* Decorative index numeral — the <ol> already conveys step
                  order semantically and aria-hidden removes the redundant
                  announcement, but a sighted low-vision visitor still sees
                  this text, so it also needs real contrast (WCAG 1.4.3 isn't
                  satisfied by aria-hidden alone). black/45 measures ~3:1
                  against the white section background — the minimum for
                  large bold text. */}
              <span aria-hidden="true" className="font-display text-4xl font-bold text-black/45">
                {String(step.step).padStart(2, "0")}
              </span>
              <h3 className="mt-3 text-xl">{step.title}</h3>
              <p className="mt-2 text-base leading-relaxed text-muted-dark">{step.body}</p>
            </li>
          ))}
        </ol>
      </Container>
    </section>
  );
}
