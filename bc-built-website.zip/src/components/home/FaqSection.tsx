import { homeFaqs } from "@/content/faqs";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { FaqList } from "@/components/ui/Faq";

export function FaqSection() {
  return (
    <section className="bg-white py-16 md:py-24">
      <div className="mx-auto w-full max-w-3xl px-(--gutter)">
        <SectionHeading title="Frequently asked questions" align="center" />
        <div className="mt-10">
          <FaqList items={homeFaqs} />
        </div>
      </div>
    </section>
  );
}
