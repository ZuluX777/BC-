import { business } from "@/content/business";
import { Button } from "@/components/ui/Button";
import { Container } from "@/components/ui/Container";
import { Eyebrow } from "@/components/ui/Eyebrow";
import { Rule } from "@/components/ui/Rule";
import { Logo } from "@/components/layout/Logo";

export function AboutSection() {
  return (
    <section className="bg-ink py-16 text-white md:py-24">
      <Container className="grid gap-10 md:grid-cols-[1fr_1.1fr] md:items-center md:gap-16">
        <div className="flex items-center justify-center rounded bg-coal p-10 md:p-14">
          <Logo className="h-20 md:h-24" />
        </div>
        <div>
          <Eyebrow>About BC Built</Eyebrow>
          <h2 className="mt-2 text-3xl md:text-4xl">Meet Brandon.</h2>
          <Rule className="mt-4" />
          <p className="mt-6 max-w-xl text-base leading-relaxed text-body-light md:text-lg">
            {business.director} is the director of {business.name}, a building, renovations and property maintenance
            business serving {business.locationLabel.replace(" | ", " and ")}. Have something in mind for your
            property? Get in touch and tell him about it.
          </p>
          <div className="mt-8 flex flex-wrap gap-4">
            <Button href="/contact" variant="secondary" showArrow>
              Talk to Brandon about your project
            </Button>
            <Button href="/about" variant="ghost">
              More about BC Built
            </Button>
          </div>
        </div>
      </Container>
    </section>
  );
}
