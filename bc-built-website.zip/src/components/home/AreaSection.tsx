import { confirmedCoverage } from "@/content/areas";
import { Button } from "@/components/ui/Button";
import { Container } from "@/components/ui/Container";
import { SectionHeading } from "@/components/ui/SectionHeading";

export function AreaSection() {
  return (
    <section className="bg-paper py-16 md:py-24">
      <Container className="grid gap-10 md:grid-cols-[1.1fr_0.9fr] md:items-center md:gap-16">
        <div>
          <SectionHeading title={`${confirmedCoverage[0]}. Across ${confirmedCoverage[1]}.`} align="left" />
          <p className="mt-6 max-w-lg text-base leading-relaxed text-muted-dark md:text-lg">
            Tell us where your property is and what you need doing. We will confirm whether we can help in your area.
          </p>
          <div className="mt-8">
            <Button href="/areas-we-cover" variant="secondary" showArrow>
              Check your area
            </Button>
          </div>
        </div>
        <div className="rounded border border-black/10 bg-white p-8 md:p-10">
          <p className="font-display text-sm font-semibold uppercase tracking-[0.14em] text-muted-dark">
            Confirmed coverage
          </p>
          <ul className="mt-4 space-y-3">
            {confirmedCoverage.map((area) => (
              <li key={area} className="flex items-center gap-3 text-lg font-semibold text-body-dark">
                <span className="h-2 w-2 shrink-0 rounded-full bg-yellow" aria-hidden="true" />
                {area}
              </li>
            ))}
          </ul>
        </div>
      </Container>
    </section>
  );
}
