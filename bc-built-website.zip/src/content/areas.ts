/**
 * Coverage geography. Only Brighton & Hove and Sussex are established by the
 * brief. Nearby towns are research candidates, not confirmed individual
 * service locations — they are listed here only as prompts to help a visitor
 * describe where they are, never as SEO location pages (no per-town page is
 * generated from this list, and none should be added until Brandon confirms
 * coverage and there is genuinely distinctive content for it).
 */
export const confirmedCoverage = ["Brighton & Hove", "Sussex"] as const;

export const nearbyCandidateTowns = [
  "Worthing",
  "Lewes",
  "Shoreham-by-Sea",
  "Portslade",
] as const;
