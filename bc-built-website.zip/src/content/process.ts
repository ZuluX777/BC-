/**
 * Proposed operating copy — flagged in the brief for Brandon's factual
 * approval before launch. Do not read this as an unconditional free-survey,
 * fixed-price or response-time guarantee; the copy is written to avoid
 * implying one.
 */
export interface ProcessStep {
  step: number;
  title: string;
  body: string;
}

export const processSteps: ProcessStep[] = [
  {
    step: 1,
    title: "Tell us about the job.",
    body: "Share your postcode, the work you have in mind and your preferred timing.",
  },
  {
    step: 2,
    title: "Discuss what is needed.",
    body: "We can talk through the details and whether a site visit is the right next step.",
  },
  {
    step: 3,
    title: "Agree the next step.",
    body: "Confirm the scope and quotation arrangements before any work is booked.",
  },
];
