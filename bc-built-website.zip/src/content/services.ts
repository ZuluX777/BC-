/**
 * The three verified service categories. `enquiryValue` is the only value
 * ever written into the enquiry form / email from a link — it is validated
 * server-side against this same allowlist (see lib/validation.ts).
 */

export type ServiceSlug = "building" | "renovations" | "property-maintenance";

export interface ServiceUsefulDetail {
  label: string;
}

export interface Service {
  slug: ServiceSlug;
  enquiryValue: string;
  navLabel: string;
  cardTitle: string;
  cardBody: string;
  cardLinkLabel: string;
  h1: string;
  intro: string;
  usefulDetailsHeading: string;
  usefulDetails: ServiceUsefulDetail[];
  ctaLabel: string;
  metaTitle: string;
  metaDescription: string;
}

export const services: Service[] = [
  {
    slug: "building",
    enquiryValue: "Building",
    navLabel: "Building",
    cardTitle: "Building",
    cardBody:
      "Have a building project in mind? Share the location and the work you are considering so we can discuss what is needed.",
    cardLinkLabel: "Discuss building work",
    h1: "Building work in Brighton & Hove.",
    intro:
      "Planning work on your property? Tell BC Built where it is, what you would like to achieve and whether you already have plans. Brandon can discuss the project and the information needed for the next step.",
    usefulDetailsHeading: "Useful details to share",
    usefulDetails: [
      { label: "Property postcode" },
      { label: "The work you have in mind" },
      { label: "Drawings, if you have them" },
      { label: "Your desired timing" },
    ],
    ctaLabel: "Discuss your building project",
    metaTitle: "Building Work in Brighton & Hove | BC Built",
    metaDescription:
      "Planning building work in Brighton, Hove or Sussex? Contact BC Built with your postcode and project details to discuss the next step.",
  },
  {
    slug: "renovations",
    enquiryValue: "Renovations",
    navLabel: "Renovations",
    cardTitle: "Renovations",
    cardBody:
      "Ready to make a change to your property? Tell us what you would like to improve and where you are in the planning process.",
    cardLinkLabel: "Discuss a renovation",
    h1: "Property renovations in Brighton & Hove.",
    intro:
      "A renovation starts with understanding what you want to change. Tell BC Built about the property, the spaces involved and the result you have in mind.",
    usefulDetailsHeading: "Where are you in the process?",
    usefulDetails: [
      { label: "Early ideas" },
      { label: "Planning the work" },
      { label: "Ready to discuss a quotation" },
    ],
    ctaLabel: "Discuss your renovation",
    metaTitle: "Property Renovations in Brighton & Hove | BC Built",
    metaDescription:
      "Considering a property renovation in Brighton & Hove? Tell BC Built what you would like to change and discuss your project with Brandon.",
  },
  {
    slug: "property-maintenance",
    enquiryValue: "Property maintenance",
    navLabel: "Property maintenance",
    cardTitle: "Property maintenance",
    cardBody:
      "Have a repair or a list of jobs to work through? Send a few details about the property and what needs attention.",
    cardLinkLabel: "Discuss maintenance",
    h1: "Property maintenance in Brighton & Hove.",
    intro:
      "If your property needs attention, start by telling us what needs doing. Share the postcode and a short description of the job, whether it is one repair or several items to discuss.",
    usefulDetailsHeading: "Useful details to share",
    usefulDetails: [
      { label: "Property access" },
      { label: "Description of the job" },
      { label: "Preferred timing" },
    ],
    ctaLabel: "Discuss maintenance work",
    metaTitle: "Property Maintenance in Brighton & Hove | BC Built",
    metaDescription:
      "Need property maintenance in Brighton, Hove or Sussex? Send BC Built a few details about the work and your preferred timing.",
  },
];

export const serviceEnquiryValues = services.map((s) => s.enquiryValue);

export const enquiryServiceOptions = [
  ...services.map((s) => ({ value: s.enquiryValue, label: s.cardTitle })),
  { value: "Not sure yet", label: "Not sure yet" },
] as const;

export type EnquiryServiceValue = (typeof enquiryServiceOptions)[number]["value"];

export function getServiceBySlug(slug: string): Service | undefined {
  return services.find((s) => s.slug === slug);
}
