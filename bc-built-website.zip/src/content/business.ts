/**
 * Centralised, verified business facts.
 *
 * Every field here is sourced from the supplied BC Built business card and
 * logo, or from the build brief. Do not add unverified claims (company
 * registration, insurance, memberships, review counts, opening hours) here —
 * see LAUNCH-CHECKLIST.md "requires owner input" for what is still missing.
 */

export const business = {
  name: "BC Built",
  legalNoteVerified: false, // trading status (sole trader / Ltd) not confirmed — see launch checklist
  director: "Brandon Cunningham",
  directorTitle: "Director",
  tagline: "Building · Renovations · Property Maintenance",
  services: ["Building", "Renovations", "Property Maintenance"] as const,
  locationLabel: "Brighton & Hove | Sussex",
  region: "Sussex",
  town: "Brighton & Hove",
  email: "info@bcbuilt.co.uk",
  phoneDisplay: "07392 361921",
  phoneInternationalDisplay: "+44 7392 361921",
  phoneHref: "+447392361921",
  // Printed on the business card. Live retrieval attempts failed during
  // research; this does not prove the domain is unregistered. Treated as the
  // eventual production origin once confirmed — see SITE_URL in .env.example.
  siteUrlPrinted: "https://www.bcbuilt.co.uk",
  addressVerified: false, // no street address confirmed — required for LocalBusiness rich results; do not fabricate
} as const;

export type Business = typeof business;
