export interface Faq {
  question: string;
  answer: string;
}

export const homeFaqs: Faq[] = [
  {
    question: "What type of work can I enquire about?",
    answer:
      "Building, renovations and property maintenance. Describe the work you have in mind so BC Built can confirm whether it is a suitable fit.",
  },
  {
    question: "Do I need plans before getting in touch?",
    answer:
      "You can make an initial enquiry without plans. Tell us what you are considering and whether you have drawings or other information available.",
  },
  {
    question: "What should I include in my enquiry?",
    answer:
      "Your postcode, a short description of the job and any preferred timing. If you have photos or plans, mention them so they can be requested by email.",
  },
  {
    question: "Can I email instead?",
    answer:
      "Yes. Send the details to info@bcbuilt.co.uk, or call 07392 361921.",
  },
  {
    question: "How much will the work cost?",
    answer:
      "That depends on the scope and what the property needs. Share the details so the quotation requirements can be discussed.",
  },
];
