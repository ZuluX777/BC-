/**
 * Per-route metadata, taken directly from the build brief's SEO table
 * (section H). Kept centralised so every route reads from one source.
 */
export interface RouteSeo {
  title: string;
  description: string;
}

export const routeSeo: Record<string, RouteSeo> = {
  "/": {
    title: "BC Built | Builders in Brighton & Hove",
    description:
      "Building, renovations and property maintenance in Brighton & Hove and Sussex. Tell Brandon at BC Built about your project.",
  },
  "/services": {
    title: "Building, Renovation & Maintenance Services | BC Built",
    description:
      "Building, renovations and property maintenance in Brighton & Hove and Sussex. Choose a service to discuss your project with BC Built.",
  },
  "/services/building": {
    title: "Building Work in Brighton & Hove | BC Built",
    description:
      "Planning building work in Brighton, Hove or Sussex? Contact BC Built with your postcode and project details to discuss the next step.",
  },
  "/services/renovations": {
    title: "Property Renovations in Brighton & Hove | BC Built",
    description:
      "Considering a property renovation in Brighton & Hove? Tell BC Built what you would like to change and discuss your project with Brandon.",
  },
  "/services/property-maintenance": {
    title: "Property Maintenance in Brighton & Hove | BC Built",
    description:
      "Need property maintenance in Brighton, Hove or Sussex? Send BC Built a few details about the work and your preferred timing.",
  },
  "/about": {
    title: "About BC Built | Brandon Cunningham",
    description:
      "Meet Brandon Cunningham and BC Built, serving Brighton & Hove and Sussex with building, renovations and property maintenance.",
  },
  "/areas-we-cover": {
    title: "Areas We Cover | BC Built",
    description:
      "BC Built serves Brighton & Hove and Sussex. Tell us where your property is and what you need doing.",
  },
  "/contact": {
    title: "Contact BC Built | Discuss Your Project",
    description:
      "Tell Brandon about your building, renovation or maintenance project. Use our enquiry form, email info@bcbuilt.co.uk or call 07392 361921.",
  },
  "/projects": {
    title: "Our Work | BC Built",
    description:
      "Recent building, renovation and property maintenance projects from BC Built in Brighton & Hove and Sussex.",
  },
  "/privacy": {
    title: "Privacy Notice | BC Built",
    description:
      "How BC Built collects, uses and protects information submitted through this website.",
  },
  "/terms": {
    title: "Website Terms of Use | BC Built",
    description: "Terms governing use of the BC Built website.",
  },
  "/cookies": {
    title: "Cookies | BC Built",
    description:
      "The cookies and similar technologies used on the BC Built website, and how to manage your preferences.",
  },
};
