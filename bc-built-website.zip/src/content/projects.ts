/**
 * Verified project case studies.
 *
 * This is a new business — no owner-approved project photography or project
 * facts have been supplied. The array is intentionally empty. Do not add a
 * placeholder, fictional or stock-photo entry here: every consumer of this
 * data (homepage "work" section, /projects, /projects/[slug], sitemap,
 * navigation) hides itself automatically when the list is empty, per the
 * build brief ("do not publish empty project pages").
 *
 * To publish a real project once Brandon supplies photography and
 * permission:
 *   1. Add owner-approved images to /public/images/projects/<slug>/.
 *   2. Add an entry below with `verified: true`.
 *   3. Do not include street addresses, costs or customer names without
 *      explicit permission — town/neighbourhood level location only.
 */

export interface Project {
  slug: string;
  verified: boolean;
  title: string;
  locationLabel: string; // town/neighbourhood level only — never a street address
  service: string;
  brief: string;
  work: string;
  result: string;
  coverImage: string;
  coverImageAlt: string;
  featured?: boolean;
}

export const projects: Project[] = [];

export const verifiedProjects = projects.filter((p) => p.verified);

export function getProjectBySlug(slug: string): Project | undefined {
  return verifiedProjects.find((p) => p.slug === slug);
}
