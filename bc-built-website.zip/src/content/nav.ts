export interface NavLink {
  href: string;
  label: string;
}

export const primaryNav: NavLink[] = [
  { href: "/services", label: "Services" },
  { href: "/about", label: "About" },
  { href: "/areas-we-cover", label: "Areas we cover" },
  { href: "/contact", label: "Contact" },
];

// "Our work" is only shown in navigation once verified project entries
// exist — see content/projects.ts and components/layout/Header.tsx.
export const workNavLink: NavLink = { href: "/projects", label: "Our work" };

export const primaryCtaLabel = "Tell us about your project";

// Routes where the mobile bottom CTA bar hides itself — the enquiry form
// (and the on-screen keyboard while it's being filled in) lives only here.
export const mobileCtaHiddenRoutes = ["/contact", "/thank-you"];

export const footerNav: NavLink[] = [
  ...primaryNav,
  { href: "/privacy", label: "Privacy notice" },
  { href: "/terms", label: "Terms of use" },
  { href: "/cookies", label: "Cookies" },
];
