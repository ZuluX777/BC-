/**
 * Deliberately forgiving UK postcode handling. Per the build brief this must
 * NOT be an API-dependent address lookup and must NOT hard-reject anything
 * outside a BN (Brighton) prefix — BC Built's stated coverage is Brighton &
 * Hove and wider Sussex, and enquiries may come from just outside that too.
 *
 * We normalise for display/consistency and apply a loose shape check that
 * catches empty or obviously-not-a-postcode input without being a strict
 * postal validator that could reject a real, slightly unusual postcode.
 */

export function normalisePostcode(raw: string): string {
  const compact = raw.trim().toUpperCase().replace(/\s+/g, "");
  if (compact.length <= 3) return compact;
  const outward = compact.slice(0, -3);
  const inward = compact.slice(-3);
  return `${outward} ${inward}`;
}

export function isPlausiblePostcode(raw: string): boolean {
  const compact = raw.trim().toUpperCase().replace(/\s+/g, "");
  if (compact.length < 5 || compact.length > 8) return false;
  const hasLetter = /[A-Z]/.test(compact);
  const hasDigit = /[0-9]/.test(compact);
  const onlyAllowedChars = /^[A-Z0-9]+$/.test(compact);
  return hasLetter && hasDigit && onlyAllowedChars;
}
