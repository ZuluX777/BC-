import "server-only";
import { getTurnstileServerConfig, isProduction } from "@/lib/env";

/**
 * Server-verified Cloudflare Turnstile check.
 * https://developers.cloudflare.com/turnstile/get-started/server-side-validation/
 *
 * Turnstile is optional configuration. When it is not configured:
 *  - in production, the request is NOT silently waved through — the
 *    honeypot field and rate limiting still apply in full, and this is
 *    surfaced as a configuration gap in the launch checklist, not hidden.
 *  - in local/test environments, it is expected to be unset and is skipped
 *    without warning noise.
 */
export type TurnstileOutcome = "verified" | "not-configured" | "failed";

export async function verifyTurnstile(token: string | undefined | null, remoteIp: string | undefined): Promise<TurnstileOutcome> {
  const config = getTurnstileServerConfig();
  if (!config) {
    return "not-configured";
  }
  if (!token) {
    return "failed";
  }

  try {
    const response = await fetch("https://challenges.cloudflare.com/turnstile/v0/siteverify", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        secret: config.secretKey,
        response: token,
        ...(remoteIp ? { remoteip: remoteIp } : {}),
      }),
      signal: AbortSignal.timeout(5000),
    });
    if (!response.ok) return "failed";
    const data = (await response.json()) as { success: boolean };
    return data.success ? "verified" : "failed";
  } catch {
    // Network failure/timeout talking to Cloudflare — fail closed in
    // production (treat as failed), but never crash the request.
    return isProduction() ? "failed" : "not-configured";
  }
}
