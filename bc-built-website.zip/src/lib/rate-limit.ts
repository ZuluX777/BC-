import "server-only";
import { Ratelimit } from "@upstash/ratelimit";
import { Redis } from "@upstash/redis";
import { getUpstashConfig } from "@/lib/env";

/**
 * Enquiry submission rate limiting.
 *
 * With UPSTASH_REDIS_REST_URL / _TOKEN configured, uses @upstash/ratelimit's
 * sliding window against Upstash Redis — correct across every concurrent
 * Vercel function instance. See https://upstash.com/docs/redis/sdks/ratelimit-ts/overview
 *
 * Without that configuration we fall back to a simple in-memory sliding
 * window. That fallback is per-instance only and is NOT sufficient
 * protection in a real serverless deployment with multiple concurrent
 * instances — it exists so the form still has some throttling in local
 * development, not as a production substitute. This gap is called out in
 * LAUNCH-CHECKLIST.md.
 */

const WINDOW_SECONDS = 60;
const MAX_REQUESTS = 5;

let ratelimiter: Ratelimit | null | undefined;

function getRatelimiter(): Ratelimit | null {
  if (ratelimiter !== undefined) return ratelimiter;
  const config = getUpstashConfig();
  if (!config) {
    ratelimiter = null;
    return ratelimiter;
  }
  const redis = new Redis({ url: config.url, token: config.token });
  ratelimiter = new Ratelimit({
    redis,
    limiter: Ratelimit.slidingWindow(MAX_REQUESTS, `${WINDOW_SECONDS} s`),
    prefix: "bcbuilt:enquiry-ratelimit",
    analytics: false,
  });
  return ratelimiter;
}

interface MemoryBucket {
  timestamps: number[];
}
const memoryBuckets = new Map<string, MemoryBucket>();

function memoryRateLimit(identifier: string): { success: boolean; limit: number; remaining: number } {
  const now = Date.now();
  const windowStart = now - WINDOW_SECONDS * 1000;
  const bucket = memoryBuckets.get(identifier) ?? { timestamps: [] };
  bucket.timestamps = bucket.timestamps.filter((t) => t > windowStart);
  const success = bucket.timestamps.length < MAX_REQUESTS;
  if (success) bucket.timestamps.push(now);
  memoryBuckets.set(identifier, bucket);
  return { success, limit: MAX_REQUESTS, remaining: Math.max(0, MAX_REQUESTS - bucket.timestamps.length) };
}

export interface RateLimitResult {
  success: boolean;
  limit: number;
  remaining: number;
  distributed: boolean;
}

export async function checkRateLimit(identifier: string): Promise<RateLimitResult> {
  const limiter = getRatelimiter();
  if (limiter) {
    const result = await limiter.limit(identifier);
    return { success: result.success, limit: result.limit, remaining: result.remaining, distributed: true };
  }
  const result = memoryRateLimit(identifier);
  return { ...result, distributed: false };
}
