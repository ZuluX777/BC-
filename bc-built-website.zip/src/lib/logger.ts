import "server-only";

/**
 * Deliberately narrow server logging for the enquiry endpoint. Logs a
 * reference, outcome status and (when available) the email provider's
 * message id — never the full enquiry body, name, email, phone or postcode,
 * and never a secret/API key.
 */
export function logEnquiryOutcome(entry: {
  reference: string;
  status: "sent" | "unavailable" | "error" | "rejected" | "duplicate";
  detail?: string;
  providerMessageId?: string;
}) {
  const { reference, status, providerMessageId, detail } = entry;
  console.log(
    JSON.stringify({
      event: "enquiry_outcome",
      reference,
      status,
      providerMessageId: providerMessageId ?? null,
      detail: detail ?? null,
      timestamp: new Date().toISOString(),
    }),
  );
}
