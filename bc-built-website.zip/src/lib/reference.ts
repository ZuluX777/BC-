import { randomBytes } from "crypto";

/**
 * Opaque enquiry reference — never derived from or containing personal data,
 * safe to show on the thank-you page and to quote back over email or phone.
 */
export function generateEnquiryReference(): string {
  const bytes = randomBytes(4);
  const code = bytes.toString("hex").toUpperCase();
  return `BCB-${code}`;
}
