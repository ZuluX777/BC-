import { z } from "zod";
import { enquiryServiceOptions } from "@/content/services";
import { isPlausiblePostcode } from "@/lib/postcode";

/**
 * Single source of truth for enquiry form validation, imported by both the
 * client form (inline errors) and the server API route (authoritative
 * check). Never trust the client-side pass alone.
 */

const serviceValues = enquiryServiceOptions.map((o) => o.value) as [string, ...string[]];

export const timingOptions = [
  "Exploring options",
  "Within a month",
  "1–3 months",
  "Later",
  "Not sure",
] as const;

export const budgetOptions = [
  "Under £2,000",
  "£2,000–£10,000",
  "£10,000–£25,000",
  "£25,000–£50,000",
  "£50,000+",
  "Not sure yet",
] as const;

export const preferredReplyOptions = ["Email", "Phone"] as const;

export const step1Schema = z.object({
  service: z.enum(serviceValues, {
    message: "Choose the service you would like to discuss.",
  }),
  postcode: z
    .string()
    .trim()
    .min(1, "Enter your property postcode.")
    .refine(isPlausiblePostcode, {
      message: "Enter a valid UK postcode, for example BN1 1AB.",
    }),
  description: z
    .string()
    .trim()
    .min(20, "Tell us a little more — at least 20 characters helps Brandon understand the job.")
    .max(2000, "Keep your description under 2,000 characters."),
  timing: z.enum(timingOptions).optional().or(z.literal("")),
  budget: z.enum(budgetOptions).optional().or(z.literal("")),
});

export type Step1Values = z.infer<typeof step1Schema>;

const phoneRegex = /^[+()0-9\s-]{7,20}$/;

export const step2Schema = z
  .object({
    name: z
      .string()
      .trim()
      .min(2, "Enter your name.")
      .max(120, "Enter a shorter name.")
      .regex(/^[\p{L}\p{M}\s.'-]+$/u, "Enter a valid name."),
    email: z.string().trim().min(1, "Enter your email address.").email("Enter a valid email address."),
    phone: z
      .string()
      .trim()
      .max(20, "Enter a shorter phone number.")
      .regex(phoneRegex, "Enter a valid phone number.")
      .optional()
      .or(z.literal("")),
    preferredReply: z.enum(preferredReplyOptions),
    hasPhotos: z.boolean().optional(),
    // Honeypot — a real visitor never sees or fills this field. Deliberately
    // NOT constrained to an empty string here: if a bot does fill it, this
    // must still pass validation and reach the API route's honeypot check,
    // which silently returns a fake success with no signal that anything
    // was detected. Rejecting it at the schema level instead (e.g. max(0))
    // would leak a distinguishing "company: too long" validation error back
    // to the bot, defeating the point of a honeypot.
    company: z.string().max(500).optional().or(z.literal("")),
  })
  .refine(
    (data) => data.preferredReply !== "Phone" || (data.phone && data.phone.trim().length > 0),
    {
      message: "Enter a phone number, or choose Email as your preferred reply.",
      path: ["phone"],
    },
  );

export type Step2Values = z.infer<typeof step2Schema>;

export const enquirySchema = step1Schema.and(step2Schema).and(
  z.object({
    idempotencyKey: z.string().uuid(),
    // Populated only when the Turnstile widget is configured and rendered.
    turnstileToken: z.string().optional().or(z.literal("")),
    source: z.enum(["homepage", "building", "renovations", "property-maintenance", "contact", "other"]).default("other"),
  }),
);

export type EnquiryValues = z.infer<typeof enquirySchema>;

export const enquiryDefaults: Partial<EnquiryValues> = {
  service: undefined,
  postcode: "",
  description: "",
  timing: "",
  budget: "",
  name: "",
  email: "",
  phone: "",
  preferredReply: "Email",
  hasPhotos: false,
  company: "",
};
