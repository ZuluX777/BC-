/**
 * Build a link to the contact route with a service preselected. The value
 * is validated server-side against the same allowlist used by the form
 * (see content/services.ts / lib/validation.ts) — this is just a URL
 * convenience, never trusted on its own.
 */
export function contactHrefForService(enquiryValue: string): string {
  return `/contact?service=${encodeURIComponent(enquiryValue)}`;
}
