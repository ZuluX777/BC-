import "server-only";
import { Redis } from "@upstash/redis";
import { getUpstashConfig } from "@/lib/env";

/**
 * Minimal set-if-not-exists key/value store with TTL, used for the enquiry
 * idempotency check. Backed by Upstash Redis (durable, shared across all
 * serverless instances) when UPSTASH_REDIS_REST_URL / _TOKEN are configured.
 *
 * Without those variables we fall back to an in-memory Map. That fallback
 * is PER INSTANCE ONLY — on Vercel, concurrent requests can land on
 * different instances and the fallback will not catch a duplicate between
 * them. This is a documented, intentional gap (see LAUNCH-CHECKLIST.md);
 * the honeypot and server-side validation still apply regardless.
 */

let redisClient: Redis | null | undefined;

function getRedis(): Redis | null {
  if (redisClient !== undefined) return redisClient;
  const config = getUpstashConfig();
  redisClient = config ? new Redis({ url: config.url, token: config.token }) : null;
  return redisClient;
}

interface MemoryEntry {
  value: string;
  expiresAt: number;
}

const memoryStore = new Map<string, MemoryEntry>();

function pruneMemoryStore() {
  const now = Date.now();
  for (const [key, entry] of memoryStore) {
    if (entry.expiresAt <= now) memoryStore.delete(key);
  }
}

/**
 * Atomically set `key` to `value` only if it does not already exist, with a
 * TTL in seconds. Returns true if this call set the value (first time seen),
 * false if the key already existed (a duplicate).
 */
export async function setIfAbsent(key: string, value: string, ttlSeconds: number): Promise<boolean> {
  const redis = getRedis();
  if (redis) {
    const result = await redis.set(key, value, { nx: true, ex: ttlSeconds });
    return result === "OK";
  }

  pruneMemoryStore();
  if (memoryStore.has(key)) return false;
  memoryStore.set(key, { value, expiresAt: Date.now() + ttlSeconds * 1000 });
  return true;
}

export async function get(key: string): Promise<string | null> {
  const redis = getRedis();
  if (redis) {
    const value = await redis.get<string>(key);
    return value ?? null;
  }
  pruneMemoryStore();
  return memoryStore.get(key)?.value ?? null;
}

/** Overwrite an existing key's value in place, keeping (or setting) a TTL. */
export async function set(key: string, value: string, ttlSeconds: number): Promise<void> {
  const redis = getRedis();
  if (redis) {
    await redis.set(key, value, { ex: ttlSeconds });
    return;
  }
  memoryStore.set(key, { value, expiresAt: Date.now() + ttlSeconds * 1000 });
}

/**
 * Release a claimed key. Used to undo an idempotency claim when the
 * underlying operation (sending the enquiry email) did not actually
 * succeed, so a genuine retry with the same key gets a fresh attempt
 * instead of a cached failure being replayed back as a false success.
 */
export async function del(key: string): Promise<void> {
  const redis = getRedis();
  if (redis) {
    await redis.del(key);
    return;
  }
  memoryStore.delete(key);
}

export function isDistributedStoreConfigured(): boolean {
  return getUpstashConfig() !== null;
}
