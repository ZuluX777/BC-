import "server-only";
import { Resend } from "resend";
import { getEmailConfig } from "@/lib/env";
import { escapeHtml, stripHeaderControlChars } from "@/lib/sanitize";
import type { EnquiryValues } from "@/lib/validation";

export interface EnquiryEmailInput extends EnquiryValues {
  reference: string;
  normalisedPostcode: string;
  submittedAtIso: string;
}

export type SendEnquiryEmailResult =
  | { status: "sent"; providerMessageId: string }
  | { status: "unavailable"; reason: string }
  | { status: "error"; reason: string };

function formatLondonTimestamp(iso: string): string {
  return new Date(iso).toLocaleString("en-GB", {
    timeZone: "Europe/London",
    dateStyle: "long",
    timeStyle: "short",
  });
}

function buildSubject(input: EnquiryEmailInput): string {
  const service = stripHeaderControlChars(input.service);
  const postcode = stripHeaderControlChars(input.normalisedPostcode);
  const reference = stripHeaderControlChars(input.reference);
  return `BC Built enquiry | ${service} | ${postcode} | ${reference}`;
}

function buildTextBody(input: EnquiryEmailInput): string {
  const lines = [
    `New enquiry via bcbuilt.co.uk — reference ${input.reference}`,
    `Submitted: ${formatLondonTimestamp(input.submittedAtIso)} (Europe/London)`,
    "",
    `Service: ${input.service}`,
    `Postcode: ${input.normalisedPostcode}`,
    `Description:`,
    input.description,
    "",
    input.timing ? `Preferred timing: ${input.timing}` : null,
    input.budget ? `Approximate budget: ${input.budget}` : null,
    "",
    `Name: ${input.name}`,
    `Email: ${input.email}`,
    input.phone ? `Phone: ${input.phone}` : "Phone: (not provided)",
    `Preferred reply method: ${input.preferredReply}`,
    `Has photos/plans to share: ${input.hasPhotos ? "Yes — customer will email them" : "No"}`,
    "",
    `Source: ${input.source}`,
  ].filter((line): line is string => line !== null);
  return lines.join("\n");
}

function buildHtmlBody(input: EnquiryEmailInput): string {
  const row = (label: string, value: string) =>
    `<tr><td style="padding:4px 12px 4px 0;color:#5B6059;white-space:nowrap;vertical-align:top;">${escapeHtml(label)}</td><td style="padding:4px 0;color:#272A27;">${escapeHtml(value)}</td></tr>`;

  const rows = [
    row("Reference", input.reference),
    row("Submitted", `${formatLondonTimestamp(input.submittedAtIso)} (Europe/London)`),
    row("Service", input.service),
    row("Postcode", input.normalisedPostcode),
    input.timing ? row("Preferred timing", input.timing) : "",
    input.budget ? row("Approximate budget", input.budget) : "",
    row("Name", input.name),
    row("Email", input.email),
    row("Phone", input.phone || "(not provided)"),
    row("Preferred reply", input.preferredReply),
    row("Photos/plans to follow", input.hasPhotos ? "Yes" : "No"),
    row("Source", input.source),
  ].join("");

  return `<!doctype html>
<html lang="en-GB">
  <body style="font-family:Arial,Helvetica,sans-serif;background:#F6F4EE;padding:24px;margin:0;">
    <table role="presentation" width="100%" style="max-width:560px;margin:0 auto;background:#FFFFFF;border-radius:8px;overflow:hidden;">
      <tr><td style="background:#101110;padding:20px 24px;">
        <span style="color:#F7C600;font-family:Arial,Helvetica,sans-serif;font-weight:800;letter-spacing:0.04em;font-size:20px;">BC BUILT</span>
      </td></tr>
      <tr><td style="padding:24px;">
        <h1 style="font-size:18px;margin:0 0 16px;color:#101110;">New project enquiry</h1>
        <table role="presentation" style="font-size:14px;line-height:1.5;">${rows}</table>
        <h2 style="font-size:14px;color:#101110;margin:20px 0 4px;">Description</h2>
        <p style="font-size:14px;line-height:1.6;color:#272A27;white-space:pre-wrap;">${escapeHtml(input.description)}</p>
      </td></tr>
    </table>
  </body>
</html>`;
}

let resendClient: Resend | null | undefined;

function getResendClient(): Resend | null {
  if (resendClient !== undefined) return resendClient;
  const config = getEmailConfig();
  resendClient = config ? new Resend(config.apiKey) : null;
  return resendClient;
}

/**
 * Send the internal enquiry notification to BC Built.
 *
 * Returns "unavailable" (never a simulated success) when RESEND_API_KEY,
 * ENQUIRY_FROM_EMAIL or ENQUIRY_TO_EMAIL are not configured. The caller is
 * responsible for surfacing that honestly to the visitor.
 */
export async function sendEnquiryEmail(input: EnquiryEmailInput): Promise<SendEnquiryEmailResult> {
  const config = getEmailConfig();
  const client = getResendClient();
  if (!config || !client) {
    return { status: "unavailable", reason: "Email provider is not configured (RESEND_API_KEY / ENQUIRY_FROM_EMAIL / ENQUIRY_TO_EMAIL)." };
  }

  try {
    const result = await client.emails.send({
      from: config.fromEmail,
      to: config.toEmail,
      replyTo: input.email,
      subject: buildSubject(input),
      text: buildTextBody(input),
      html: buildHtmlBody(input),
    });

    if (result.error) {
      return { status: "error", reason: result.error.message };
    }
    if (!result.data?.id) {
      return { status: "error", reason: "Provider accepted the request but returned no message id." };
    }
    return { status: "sent", providerMessageId: result.data.id };
  } catch (error) {
    const reason = error instanceof Error ? error.message : "Unknown email provider error.";
    return { status: "error", reason };
  }
}
