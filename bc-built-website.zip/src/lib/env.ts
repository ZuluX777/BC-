import "server-only";

/**
 * Server-only environment access with honest availability checks.
 *
 * Nothing here throws at import/build time — a visual preview build must
 * succeed with zero configuration. Each getter instead reports whether a
 * feature is actually usable, so callers (the enquiry API route, the
 * consent banner) can produce an honest "unavailable" state instead of a
 * simulated success. See .env.example for the full list of variables.
 */

function read(name: string): string | undefined {
  const value = process.env[name];
  return value && value.trim().length > 0 ? value.trim() : undefined;
}

export interface EmailConfig {
  apiKey: string;
  fromEmail: string;
  toEmail: string;
}

export function getEmailConfig(): EmailConfig | null {
  const apiKey = read("RESEND_API_KEY");
  const fromEmail = read("ENQUIRY_FROM_EMAIL");
  const toEmail = read("ENQUIRY_TO_EMAIL");
  if (!apiKey || !fromEmail || !toEmail) return null;
  return { apiKey, fromEmail, toEmail };
}

export interface RateLimitConfig {
  url: string;
  token: string;
}

export function getUpstashConfig(): RateLimitConfig | null {
  const url = read("UPSTASH_REDIS_REST_URL");
  const token = read("UPSTASH_REDIS_REST_TOKEN");
  if (!url || !token) return null;
  return { url, token };
}

export interface TurnstileServerConfig {
  secretKey: string;
}

export function getTurnstileServerConfig(): TurnstileServerConfig | null {
  const secretKey = read("TURNSTILE_SECRET_KEY");
  if (!secretKey) return null;
  return { secretKey };
}

export function getSiteUrl(): string {
  return (
    read("SITE_URL") ??
    (process.env.VERCEL_URL ? `https://${process.env.VERCEL_URL}` : "http://localhost:3000")
  );
}

export function isProduction(): boolean {
  return process.env.NODE_ENV === "production";
}

/**
 * True when this deployment is a Vercel Preview (not Production). Used to
 * force noindex on preview deployments regardless of other metadata.
 */
export function isPreviewDeployment(): boolean {
  return process.env.VERCEL_ENV === "preview";
}
