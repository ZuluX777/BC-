/** Escape untrusted text before interpolating into an HTML email body. */
export function escapeHtml(input: string): string {
  return input
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

/**
 * Strip characters that could be used for email header injection (CRLF and
 * other control characters) from any value that ends up in a subject line
 * or header-adjacent field. Applied in addition to schema validation, never
 * instead of it.
 */
export function stripHeaderControlChars(input: string): string {
  return input.replace(/[\r\n\u0000-\u001F\u007F]/g, "").trim();
}
