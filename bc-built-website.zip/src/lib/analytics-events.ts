/**
 * Allowlisted analytics events and property keys. Nothing outside this list
 * is ever sent — no name, email, phone, postcode, free-text description or
 * raw URL containing customer data. See build brief section J.
 */
export type AnalyticsEventName =
  | "service_cta_click"
  | "form_start"
  | "form_step_complete"
  | "form_submit_success"
  | "form_submit_failure"
  | "email_click"
  | "phone_click";

export interface AnalyticsEventProps {
  service?: string;
  placement?: string;
  step?: number;
  reason?: string;
  campaign?: string;
}

const ALLOWED_PROP_KEYS: (keyof AnalyticsEventProps)[] = ["service", "placement", "step", "reason", "campaign"];

export function sanitiseAnalyticsProps(props: AnalyticsEventProps = {}): Record<string, string | number> {
  const clean: Record<string, string | number> = {};
  for (const key of ALLOWED_PROP_KEYS) {
    const value = props[key];
    if (value === undefined) continue;
    clean[key] = typeof value === "number" ? value : String(value).slice(0, 60);
  }
  return clean;
}
