import { NextResponse } from "next/server";

/**
 * Belt-and-braces noindex for Vercel Preview deployments — sets the
 * response header in addition to robots.txt (which a crawler can choose to
 * ignore) and per-page metadata, so a preview URL never gets indexed even
 * if it is shared or linked externally.
 */
export function proxy() {
  const response = NextResponse.next();
  if (process.env.VERCEL_ENV === "preview") {
    response.headers.set("X-Robots-Tag", "noindex, nofollow");
  }
  return response;
}

export const config = {
  matcher: "/:path*",
};
