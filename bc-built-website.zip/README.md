# BC Built — website

Source for the BC Built marketing website: a Next.js (App Router) site for a
building, renovations and property maintenance business in Brighton & Hove.

Built from `BC_Built_Research_and_Claude_Build_Prompt.md`. See
**LAUNCH-CHECKLIST.md** for what is verified, what still needs real
configuration, and what can only be confirmed after deployment —
read that file before telling anyone this is ready to go live.
See **ASSET-MANIFEST.md** for the provenance of every image/logo asset.

## Stack

- Next.js 16 (App Router), React 19, TypeScript (strict)
- Tailwind CSS v4 (CSS-first `@theme` config in `src/app/globals.css` — there
  is no `tailwind.config.js`)
- Zod for shared client/server form validation
- Resend for transactional email (server-only)
- Upstash Redis for rate limiting and idempotency, with a documented
  in-memory fallback when it isn't configured
- Cloudflare Turnstile for anti-bot (optional)
- Self-hosted fonts via `@fontsource` (Barlow Condensed, Manrope) — no
  runtime Google Fonts dependency

## Local setup

```bash
npm install
cp .env.example .env.local   # see below — the site runs with all of it unset
npm run dev
```

Open http://localhost:3000.

The site is fully functional with **no environment variables set**: every
page renders, the form validates client- and server-side, and submitting it
returns an honest "we could not send your enquiry just now" response rather
than a fake success. See `.env.example` for what each variable does and
LAUNCH-CHECKLIST.md for what's required vs. optional before a real launch.

## Scripts

```bash
npm run dev      # local dev server
npm run build    # production build (also runs the TypeScript check)
npm run start    # run a production build locally
npm run lint     # ESLint
npx tsc --noEmit # TypeScript check on its own
```

All three (`build`, `lint`, `tsc --noEmit`) currently pass clean — see
LAUNCH-CHECKLIST.md for the exact results.

## Project structure

```
src/
  app/            Routes (App Router). Each route owns its own metadata,
                   sourced from src/content/seo.ts.
  app/api/enquiry  The enquiry form's server route handler (email send,
                   validation, rate limiting, idempotency).
  components/      UI, layout, form and SEO components.
  content/         Typed, centralised business facts and copy — business.ts,
                   services.ts, nav.ts, faqs.ts, process.ts, areas.ts,
                   seo.ts, projects.ts (deliberately empty — see below).
  lib/             Server-side helpers: email sending, validation schemas,
                   rate limiting, the KV store, env var access, logging.
public/
  images/          Optimised, served assets (logo, OG image).
assets-source/      Original, unprocessed uploaded assets — kept separately
                    from public/ per the brief's asset-manifest requirement.
```

### Why `content/projects.ts` is empty

BC Built is a new business with no owner-approved project photography yet.
The brief is explicit that an empty portfolio must never be published as if
it were real work. `/projects` and `/projects/[slug]` are fully built and
will activate automatically — in the main nav, in the sitemap, and as live
routes — the moment a verified entry is added to that file. Until then the
routes correctly 404, and "Our work" does not appear in navigation.

## Deploying to Vercel

1. Import the repository into Vercel.
2. Set the environment variables you want configured (see `.env.example`
   and LAUNCH-CHECKLIST.md — none are required for the site to build and
   run, but `RESEND_API_KEY` / `ENQUIRY_FROM_EMAIL` / `ENQUIRY_TO_EMAIL` are
   required for the enquiry form to actually send email).
3. Confirm `SITE_URL` matches the real production domain (www vs. non-www —
   see LAUNCH-CHECKLIST.md, this has not been decided yet).
4. Deploy, then work through LAUNCH-CHECKLIST.md's "requires owner input"
   and "not tested" rows — several things (HTTPS redirect, real inbox
   delivery, live Lighthouse scores) can only be verified once the site is
   actually live.

## What was verified in this environment

- `npm run build`, `npx tsc --noEmit` and `npm run lint`: all clean.
- A 48-check Playwright suite against a production build, covering every
  route, the full two-step enquiry form flow, keyboard navigation, the
  mobile menu's focus/Escape/scroll-lock behaviour, the honeypot, cookie
  consent, FAQ accessibility, and horizontal-overflow checks at 320/375/
  768/1024/1440px. All 48 pass. Screenshots from that run are in this
  handoff (see LAUNCH-CHECKLIST.md for the full list and what they show).
- Live curl testing of `/api/enquiry`: honest failure (never a fabricated
  success) when email isn't configured, confirmed across repeated retries
  with the same idempotency key; honeypot triggers a silent fake-success
  response with no distinguishing signal to a bot; requests from an
  unrecognised Origin are rejected.

What was **not** verified here — real email delivery, HTTPS behaviour, live
Lighthouse/Core Web Vitals, and anything else that only exists once the site
is deployed with real configuration — is listed plainly in
LAUNCH-CHECKLIST.md rather than claimed as passed.
