import type { NextConfig } from "next";

/**
 * Content-Security-Policy and friends.
 *
 * script-src / style-src include 'unsafe-inline' as a pragmatic baseline
 * (no nonce plumbing) — this was verified against real page loads (see
 * LAUNCH-CHECKLIST.md) rather than assumed safe. challenges.cloudflare.com and
 * plausible.io are allowlisted for the optional Turnstile widget and
 * optional analytics respectively; both are inert unless their env vars are
 * configured. Tightening further (nonce-based script-src) is a reasonable
 * future hardening step, not required for launch.
 */
const csp = [
  "default-src 'self'",
  "script-src 'self' 'unsafe-inline' https://challenges.cloudflare.com https://plausible.io",
  "style-src 'self' 'unsafe-inline'",
  "img-src 'self' data: blob:",
  "font-src 'self' data:",
  "connect-src 'self' https://plausible.io https://challenges.cloudflare.com",
  "frame-src https://challenges.cloudflare.com",
  "object-src 'none'",
  "base-uri 'self'",
  "form-action 'self'",
  "frame-ancestors 'none'",
  "upgrade-insecure-requests",
].join("; ");

const securityHeaders = [
  { key: "Content-Security-Policy", value: csp },
  { key: "X-Content-Type-Options", value: "nosniff" },
  { key: "X-Frame-Options", value: "DENY" },
  { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
  { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=(), interest-cohort=()" },
  { key: "Strict-Transport-Security", value: "max-age=63072000; includeSubDomains" },
];

const nextConfig: NextConfig = {
  async headers() {
    return [
      {
        source: "/:path*",
        headers: securityHeaders,
      },
    ];
  },
};

export default nextConfig;
